"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import {
  AlertCircle,
  BarChart3,
  Brain,
  Calendar,
  CreditCard,
  FileText,
  Home,
  LineChart,
  Package,
  Percent,
  QrCode,
  Settings,
  ShoppingBag,
  SplitSquareVertical,
  Sun,
  Moon,
  Users,
  Sparkles,
  Layers,
  Wifi,
  WifiOff,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const [isOnline, setIsOnline] = useState(true)
  const [theme, setTheme] = useState<"light" | "dark">("light")

  // Simulate offline/online status for demo purposes
  useEffect(() => {
    const interval = setInterval(() => {
      // 5% chance of toggling online status for demo
      if (Math.random() < 0.05) {
        setIsOnline((prev) => !prev)
      }
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light"
    setTheme(newTheme)
    document.documentElement.classList.toggle("dark", newTheme === "dark")
  }

  return (
    <div className={cn("min-h-screen bg-background", theme === "dark" ? "dark" : "")}>
      <SidebarProvider defaultOpen={true}>
        <div className="flex min-h-screen">
          <Sidebar className="border-r">
            <SidebarHeader className="flex h-14 items-center border-b px-4">
              <Link href="/" className="flex items-center gap-2 font-semibold">
                <ShoppingBag className="h-6 w-6" />
                <span>TourMerch</span>
              </Link>
              <SidebarTrigger className="ml-auto md:hidden" />
            </SidebarHeader>
            <SidebarContent>
              <SidebarGroup>
                <SidebarGroupLabel>Overview</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild isActive={pathname === "/"} tooltip="Dashboard">
                        <Link href="/">
                          <Home className="h-4 w-4" />
                          <span>Dashboard</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Live Sales">
                        <Link href="/live">
                          <BarChart3 className="h-4 w-4" />
                          <span>Live Sales</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>

              <SidebarGroup>
                <SidebarGroupLabel>Merchandise</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Payments">
                        <Link href="/payments">
                          <CreditCard className="h-4 w-4" />
                          <span>Payments</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Inventory">
                        <Link href="/inventory">
                          <Package className="h-4 w-4" />
                          <span>Inventory</span>
                        </Link>
                      </SidebarMenuButton>
                      <Badge variant="outline" className="ml-auto">
                        3
                      </Badge>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Taxes">
                        <Link href="/taxes">
                          <Percent className="h-4 w-4" />
                          <span>Taxes</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Reports">
                        <Link href="/reports">
                          <FileText className="h-4 w-4" />
                          <span>Reports</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="AI Forecasting">
                        <Link href="/forecasting">
                          <Sparkles className="h-4 w-4" />
                          <span>AI Forecasting</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>

              <SidebarGroup>
                <SidebarGroupLabel>Tour Management</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Tour Calendar">
                        <Link href="/calendar">
                          <Calendar className="h-4 w-4" />
                          <span>Tour Calendar</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="QR Self-Checkout">
                        <Link href="/qr-checkout">
                          <QrCode className="h-4 w-4" />
                          <span>QR Self-Checkout</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Fan Data">
                        <Link href="/fan-data">
                          <Users className="h-4 w-4" />
                          <span>Fan Data</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="AI Projections">
                        <Link href="/ai-projection">
                          <Brain className="h-4 w-4" />
                          <span>AI Projections</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Revenue Splits">
                        <Link href="/revenue-splits">
                          <SplitSquareVertical className="h-4 w-4" />
                          <span>Revenue Splits</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Bundle Builder">
                        <Link href="/bundle-builder">
                          <Layers className="h-4 w-4" />
                          <span>Bundle Builder</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Tour Summary">
                        <Link href="/tour-summary">
                          <LineChart className="h-4 w-4" />
                          <span>Tour Summary</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>

              <SidebarGroup>
                <SidebarGroupLabel>Settings</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="User Access">
                        <Link href="/user-access">
                          <Users className="h-4 w-4" />
                          <span>User Access</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Settings">
                        <Link href="/settings">
                          <Settings className="h-4 w-4" />
                          <span>Settings</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>
            <SidebarFooter className="border-t p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isOnline ? (
                    <Wifi className="h-4 w-4 text-green-500" />
                  ) : (
                    <WifiOff className="h-4 w-4 text-red-500" />
                  )}
                  <span className="text-sm">{isOnline ? "Online" : "Offline Mode"}</span>
                </div>
                <div className="flex items-center">
                  <Button variant="ghost" size="icon" onClick={toggleTheme}>
                    {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Separator className="my-4" />
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src="/placeholder.svg" alt="User" />
                      <AvatarFallback>TM</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col items-start text-sm">
                      <span>Tour Manager</span>
                      <span className="text-xs text-muted-foreground">Acme Band</span>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Users className="mr-2 h-4 w-4" />
                    <span>Switch Role</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </SidebarFooter>
          </Sidebar>

          <div className="flex-1 overflow-auto">
            {!isOnline && (
              <div className="bg-yellow-500/10 border-b border-yellow-500/20 p-2">
                <div className="container flex items-center gap-2 text-sm text-yellow-600 dark:text-yellow-400">
                  <AlertCircle className="h-4 w-4" />
                  <span>Offline Mode - Changes will sync when connection is restored</span>
                </div>
              </div>
            )}
            <div className="container py-6">{children}</div>
          </div>
        </div>
      </SidebarProvider>
    </div>
  )
}

function LogOut(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
  )
}
