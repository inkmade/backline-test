"use client"

import { Calendar, Check, Percent, RefreshCw } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function TaxCollectionModule() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Tax Collection</h2>
          <p className="text-muted-foreground">Manage tax rates and settings for each venue</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Sync Tax Rates
          </Button>
          <Button variant="default">
            <Percent className="mr-2 h-4 w-4" />
            Tax Settings
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Current Location Tax Preview</CardTitle>
          <CardDescription>Tax rates for The Fillmore, San Francisco</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Sales Tax Rate</span>
                  <span>8.625%</span>
                </div>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>State Tax</span>
                  <span>6.25%</span>
                </div>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>City Tax</span>
                  <span>1.25%</span>
                </div>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>Special District Tax</span>
                  <span>1.125%</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch id="tax-inclusive" />
                  <Label htmlFor="tax-inclusive">Tax-inclusive pricing</Label>
                </div>
                <div className="text-sm text-muted-foreground">
                  When enabled, displayed prices include tax. When disabled, tax is added at checkout.
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="font-medium">Example Calculation</div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>Item Price (before tax)</div>
                <div className="text-right">$25.00</div>
                <div>Sales Tax (8.625%)</div>
                <div className="text-right">$2.16</div>
                <div className="font-medium">Total Price</div>
                <div className="font-medium text-right">$27.16</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center">
          <div className="flex-1">
            <CardTitle>Tour Tax Rules</CardTitle>
            <CardDescription>Tax settings for each tour stop</CardDescription>
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All States</SelectItem>
              <SelectItem value="ca">California</SelectItem>
              <SelectItem value="ny">New York</SelectItem>
              <SelectItem value="tx">Texas</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Venue</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Tax Rate</TableHead>
                <TableHead>Tax Inclusive</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>May 12, 2025</TableCell>
                <TableCell>The Fillmore</TableCell>
                <TableCell>San Francisco, CA</TableCell>
                <TableCell>8.625%</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    <Check className="mr-1 h-3 w-3" />
                    Yes
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    Active
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>May 14, 2025</TableCell>
                <TableCell>The Warfield</TableCell>
                <TableCell>San Francisco, CA</TableCell>
                <TableCell>8.625%</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    <Check className="mr-1 h-3 w-3" />
                    Yes
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-gray-100 text-gray-500">
                    Upcoming
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>May 16, 2025</TableCell>
                <TableCell>The Wiltern</TableCell>
                <TableCell>Los Angeles, CA</TableCell>
                <TableCell>9.5%</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    <Check className="mr-1 h-3 w-3" />
                    Yes
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-gray-100 text-gray-500">
                    Upcoming
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>May 18, 2025</TableCell>
                <TableCell>The Observatory</TableCell>
                <TableCell>San Diego, CA</TableCell>
                <TableCell>7.75%</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    <Check className="mr-1 h-3 w-3" />
                    Yes
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-gray-100 text-gray-500">
                    Upcoming
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>May 21, 2025</TableCell>
                <TableCell>The Paramount</TableCell>
                <TableCell>Seattle, WA</TableCell>
                <TableCell>10.25%</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-red-50 text-red-700">
                    No
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-gray-100 text-gray-500">
                    Upcoming
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Import Tour Calendar
          </Button>
          <Button>Add Tax Rule</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
