"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { formatCurrency } from "@/lib/utils"

export function RecentSalesActivity({ salesData }) {
  const [activities, setActivities] = useState([])

  // Initialize with real sales data if available
  useEffect(() => {
    if (salesData && salesData.length > 0) {
      const formattedSales = salesData.slice(0, 4).map((sale) => {
        // Get the first item from each sale for simplicity
        const firstItem = sale.items[0]
        const itemName = firstItem.variant.item.name
        const variantName = firstItem.variant.size ? `${itemName} (${firstItem.variant.size})` : itemName

        return {
          id: sale.id,
          item: variantName,
          location: sale.show.venue.city,
          time: getTimeAgo(new Date(sale.saleTime)),
          amount: formatCurrency(sale.total),
        }
      })

      setActivities(formattedSales)
    } else {
      // Use sample data if no real data is available
      setActivities([
        {
          id: "1",
          item: "Tour Tee (L)",
          location: "Current City",
          time: "Just now",
          amount: "$35.00",
        },
        {
          id: "2",
          item: "Vinyl Record",
          location: "Current City",
          time: "2m ago",
          amount: "$25.00",
        },
        {
          id: "3",
          item: "Tour Poster",
          location: "Current City",
          time: "5m ago",
          amount: "$20.00",
        },
        {
          id: "4",
          item: "Hoodie (M)",
          location: "Current City",
          time: "8m ago",
          amount: "$55.00",
        },
      ])
    }
  }, [salesData])

  // Helper function to format time ago
  function getTimeAgo(date) {
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.round(diffMs / 60000)

    if (diffMins < 1) return "Just now"
    if (diffMins < 60) return `${diffMins}m ago`

    const diffHours = Math.floor(diffMins / 60)
    if (diffHours < 24) return `${diffHours}h ago`

    return `${Math.floor(diffHours / 24)}d ago`
  }

  // Simulate new sales coming in
  useEffect(() => {
    const items = [
      "Tour Tee (S)",
      "Tour Tee (M)",
      "Tour Tee (L)",
      "Tour Tee (XL)",
      "Hoodie (S)",
      "Hoodie (M)",
      "Hoodie (L)",
      "Vinyl Record",
      "Tour Poster",
      "Sticker Pack",
      "Hat",
      "Tote Bag",
    ]
    const locations = ["Current City"]
    const amounts = ["$35.00", "$25.00", "$20.00", "$55.00", "$15.00", "$30.00"]

    const interval = setInterval(() => {
      const newActivity = {
        id: Math.random().toString(36).substring(2, 9),
        item: items[Math.floor(Math.random() * items.length)],
        location: locations[Math.floor(Math.random() * locations.length)],
        time: "Just now",
        amount: amounts[Math.floor(Math.random() * amounts.length)],
      }

      setActivities((prev) => {
        // Update time labels
        const updated = prev.map((activity) => {
          if (activity.time === "Just now") {
            return { ...activity, time: "1m ago" }
          } else if (activity.time === "1m ago") {
            return { ...activity, time: "2m ago" }
          } else if (activity.time === "2m ago") {
            return { ...activity, time: "5m ago" }
          } else if (activity.time === "5m ago") {
            return { ...activity, time: "8m ago" }
          }
          return activity
        })

        // Add new activity and limit to 4
        return [newActivity, ...updated].slice(0, 4)
      })
    }, 8000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-center gap-4">
          <div className="space-y-1">
            <p className="text-sm font-medium leading-none">{activity.item}</p>
            <div className="flex items-center gap-2">
              <p className="text-xs text-muted-foreground">{activity.location}</p>
              <Badge variant="outline" className="text-xs">
                {activity.time}
              </Badge>
            </div>
          </div>
          <div className="ml-auto font-medium">{activity.amount}</div>
        </div>
      ))}
    </div>
  )
}
