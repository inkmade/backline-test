"use client"

import { CalendarIcon, Clock, MapPin, Plus, Truck, Users } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useState } from "react"

export function TourCalendarModule() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Sample tour dates
  const tourDates = [
    {
      id: "1",
      date: "May 12, 2025",
      venue: "The Fillmore",
      location: "San Francisco, CA",
      capacity: 1150,
      loadIn: "2:00 PM",
      doors: "7:00 PM",
      showtime: "8:00 PM",
      notes: "Merch setup in main lobby, 3 tables provided",
    },
    {
      id: "2",
      date: "May 14, 2025",
      venue: "The Warfield",
      location: "San Francisco, CA",
      capacity: 2300,
      loadIn: "1:00 PM",
      doors: "7:00 PM",
      showtime: "8:00 PM",
      notes: "Merch setup in main lobby, 2 tables provided",
    },
    {
      id: "3",
      date: "May 16, 2025",
      venue: "The Wiltern",
      location: "Los Angeles, CA",
      capacity: 1850,
      loadIn: "1:00 PM",
      doors: "7:00 PM",
      showtime: "8:00 PM",
      notes: "Merch setup in main lobby, 4 tables provided",
    },
    {
      id: "4",
      date: "May 18, 2025",
      venue: "The Observatory",
      location: "San Diego, CA",
      capacity: 1100,
      loadIn: "3:00 PM",
      doors: "7:00 PM",
      showtime: "8:00 PM",
      notes: "Merch setup in side room, 2 tables provided",
    },
    {
      id: "5",
      date: "May 21, 2025",
      venue: "The Paramount",
      location: "Seattle, WA",
      capacity: 2800,
      loadIn: "2:00 PM",
      doors: "7:00 PM",
      showtime: "8:00 PM",
      notes: "Merch setup in main lobby, 3 tables provided",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Tour Calendar</h2>
          <p className="text-muted-foreground">Manage tour dates and venue information</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <CalendarIcon className="mr-2 h-4 w-4" />
            Import Calendar
          </Button>
          <Button variant="default">
            <Plus className="mr-2 h-4 w-4" />
            Add Show
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-7">
        <Card className="md:col-span-3">
          <CardHeader>
            <CardTitle>Tour Calendar</CardTitle>
            <CardDescription>Select a date to view show details</CardDescription>
          </CardHeader>
          <CardContent>
            <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
          </CardContent>
        </Card>

        <Card className="md:col-span-4">
          <CardHeader>
            <CardTitle>Upcoming Shows</CardTitle>
            <CardDescription>Next 5 tour dates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {tourDates.map((show, index) => (
                <div key={show.id} className="space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium">
                        {show.date} - {show.venue}
                      </h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-3 w-3" />
                        <span>{show.location}</span>
                      </div>
                    </div>
                    <Badge variant="outline">{show.capacity} capacity</Badge>
                  </div>
                  <div className="flex flex-wrap gap-2 text-sm">
                    <div className="flex items-center gap-1 rounded-md bg-muted px-2 py-1">
                      <Truck className="h-3 w-3" />
                      <span>Load-in: {show.loadIn}</span>
                    </div>
                    <div className="flex items-center gap-1 rounded-md bg-muted px-2 py-1">
                      <Users className="h-3 w-3" />
                      <span>Doors: {show.doors}</span>
                    </div>
                    <div className="flex items-center gap-1 rounded-md bg-muted px-2 py-1">
                      <Clock className="h-3 w-3" />
                      <span>Show: {show.showtime}</span>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">{show.notes}</div>
                  {index < tourDates.length - 1 && <Separator className="my-2" />}
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm" className="ml-auto">
              View Full Tour
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tour Schedule</CardTitle>
          <CardDescription>Complete tour itinerary</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Venue</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Capacity</TableHead>
                <TableHead>Load-In</TableHead>
                <TableHead>Doors</TableHead>
                <TableHead>Show</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tourDates.map((show) => (
                <TableRow key={show.id}>
                  <TableCell>{show.date}</TableCell>
                  <TableCell className="font-medium">{show.venue}</TableCell>
                  <TableCell>{show.location}</TableCell>
                  <TableCell>{show.capacity}</TableCell>
                  <TableCell>{show.loadIn}</TableCell>
                  <TableCell>{show.doors}</TableCell>
                  <TableCell>{show.showtime}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
