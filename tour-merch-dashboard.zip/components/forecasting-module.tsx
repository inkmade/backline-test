"use client"

import { ArrowRight, Brain, Download, LineChart, RefreshCw, Truck } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"

export function ForecastingModule() {
  // Sample data for forecasting chart
  const forecastData = [
    { name: "May 12", actual: 1245, predicted: 1200 },
    { name: "May 14", actual: null, predicted: 1350 },
    { name: "May 16", actual: null, predicted: 1500 },
    { name: "May 18", actual: null, predicted: 1400 },
    { name: "May 21", actual: null, predicted: 1600 },
    { name: "May 23", actual: null, predicted: 1450 },
    { name: "May 25", actual: null, predicted: 1550 },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">AI Merch Forecasting</h2>
          <p className="text-muted-foreground">Predictive analytics for inventory management</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh Predictions
          </Button>
          <Button variant="default">
            <Brain className="mr-2 h-4 w-4" />
            Run AI Analysis
          </Button>
        </div>
      </div>

      <Alert className="bg-purple-50 text-purple-800 border-purple-200">
        <Brain className="h-4 w-4" />
        <AlertTitle>AI Recommendation</AlertTitle>
        <AlertDescription>
          Based on current sales trends and upcoming venues, we recommend restocking Tour Tee (L) and Tour Tee (XL)
          before the Los Angeles show on May 16.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader className="flex flex-row items-center">
          <div className="flex-1">
            <CardTitle>Sales Forecast</CardTitle>
            <CardDescription>Predicted vs. actual sales for upcoming shows</CardDescription>
          </div>
          <LineChart className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsLineChart
                data={forecastData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => [value, "Units"]} />
                <Line
                  type="monotone"
                  dataKey="actual"
                  stroke="#8884d8"
                  name="Actual Sales"
                  strokeWidth={2}
                  dot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke="#82ca9d"
                  name="Predicted Sales"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
              </RechartsLineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Predicted Best Seller</CardTitle>
            <CardDescription>Next show</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Tour Tee (L)</div>
            <p className="text-xs text-muted-foreground">Predicted to sell 180+ units in Los Angeles</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Restock Priority</CardTitle>
            <CardDescription>Items to reorder</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3 Items</div>
            <p className="text-xs text-muted-foreground">Tour Tee (L), Tour Tee (XL), Hoodie (M)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Optimal Order Timing</CardTitle>
            <CardDescription>When to restock</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-muted-foreground" />
              <div className="text-sm font-medium">Order by May 13</div>
            </div>
            <p className="text-xs text-muted-foreground">To receive before Los Angeles show</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Restock Recommendations</CardTitle>
          <CardDescription>AI-generated inventory recommendations</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead>Current Stock</TableHead>
                <TableHead>Predicted Sales</TableHead>
                <TableHead>Recommended Restock</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Tour Tee (L)</TableCell>
                <TableCell>12</TableCell>
                <TableCell>180</TableCell>
                <TableCell>200</TableCell>
                <TableCell>
                  <Badge className="bg-red-50 text-red-700">High</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm">
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Generate PO
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Tour Tee (XL)</TableCell>
                <TableCell>8</TableCell>
                <TableCell>120</TableCell>
                <TableCell>150</TableCell>
                <TableCell>
                  <Badge className="bg-red-50 text-red-700">High</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm">
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Generate PO
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Hoodie (M)</TableCell>
                <TableCell>10</TableCell>
                <TableCell>85</TableCell>
                <TableCell>100</TableCell>
                <TableCell>
                  <Badge className="bg-orange-50 text-orange-700">Medium</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm">
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Generate PO
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Tour Tee (M)</TableCell>
                <TableCell>32</TableCell>
                <TableCell>90</TableCell>
                <TableCell>75</TableCell>
                <TableCell>
                  <Badge className="bg-green-50 text-green-700">Low</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm">
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Generate PO
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Vinyl Record</TableCell>
                <TableCell>65</TableCell>
                <TableCell>50</TableCell>
                <TableCell>0</TableCell>
                <TableCell>
                  <Badge variant="outline">None</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm" disabled>
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Generate PO
                  </Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Recommendations
          </Button>
          <Button>Generate All POs</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
