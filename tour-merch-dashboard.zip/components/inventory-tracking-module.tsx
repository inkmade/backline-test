"use client"

import { AlertCircle, ArrowUp, Plus, RefreshCw, Truck } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function InventoryTrackingModule() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Inventory Tracking</h2>
          <p className="text-muted-foreground">Manage stock levels and inventory across tour dates</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Sync Inventory
          </Button>
          <Button variant="default">
            <Plus className="mr-2 h-4 w-4" />
            Add Items
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Total Items</CardTitle>
            <CardDescription>Across all venues</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4,285</div>
            <p className="text-xs text-muted-foreground">+120 since last restock</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Low Stock Items</CardTitle>
            <CardDescription>Items below threshold</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Tour Tee (L), Tour Tee (XL), Hoodie (M)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Restock Status</CardTitle>
            <CardDescription>Next delivery</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-muted-foreground" />
              <div className="text-sm font-medium">May 15, 2025</div>
            </div>
            <p className="text-xs text-muted-foreground">200 items in transit</p>
          </CardContent>
        </Card>
      </div>

      <Alert variant="destructive" className="bg-red-50 text-red-800 border-red-200">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Low Stock Alert</AlertTitle>
        <AlertDescription>
          Tour Tee (L) is running low (12 items left). Consider restocking before the next show.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader className="flex flex-row items-center">
          <div className="flex-1">
            <CardTitle>Inventory Table</CardTitle>
            <CardDescription>Current stock levels by item, size, and color</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by venue" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Venues</SelectItem>
                <SelectItem value="sf">San Francisco</SelectItem>
                <SelectItem value="la">Los Angeles</SelectItem>
                <SelectItem value="sd">San Diego</SelectItem>
              </SelectContent>
            </Select>
            <Input placeholder="Search items..." className="w-[200px]" />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead>Size/Variant</TableHead>
                <TableHead>Color</TableHead>
                <TableHead>In Stock</TableHead>
                <TableHead>Sold Today</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Tour Tee</TableCell>
                <TableCell>Small</TableCell>
                <TableCell>Black</TableCell>
                <TableCell>45</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <span>12</span>
                    <Badge variant="outline" className="text-green-500 bg-green-50">
                      <ArrowUp className="mr-1 h-3 w-3" />4
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    In Stock
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Adjust
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Tour Tee</TableCell>
                <TableCell>Medium</TableCell>
                <TableCell>Black</TableCell>
                <TableCell>32</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <span>18</span>
                    <Badge variant="outline" className="text-green-500 bg-green-50">
                      <ArrowUp className="mr-1 h-3 w-3" />6
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    In Stock
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Adjust
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Tour Tee</TableCell>
                <TableCell>Large</TableCell>
                <TableCell>Black</TableCell>
                <TableCell>12</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <span>24</span>
                    <Badge variant="outline" className="text-green-500 bg-green-50">
                      <ArrowUp className="mr-1 h-3 w-3" />8
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-red-50 text-red-700">
                    Low Stock
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Adjust
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Tour Tee</TableCell>
                <TableCell>X-Large</TableCell>
                <TableCell>Black</TableCell>
                <TableCell>8</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <span>16</span>
                    <Badge variant="outline" className="text-green-500 bg-green-50">
                      <ArrowUp className="mr-1 h-3 w-3" />5
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-red-50 text-red-700">
                    Low Stock
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Adjust
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Hoodie</TableCell>
                <TableCell>Medium</TableCell>
                <TableCell>Gray</TableCell>
                <TableCell>10</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <span>8</span>
                    <Badge variant="outline" className="text-green-500 bg-green-50">
                      <ArrowUp className="mr-1 h-3 w-3" />2
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-red-50 text-red-700">
                    Low Stock
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Adjust
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Vinyl Record</TableCell>
                <TableCell>Standard</TableCell>
                <TableCell>Black</TableCell>
                <TableCell>65</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <span>10</span>
                    <Badge variant="outline" className="text-green-500 bg-green-50">
                      <ArrowUp className="mr-1 h-3 w-3" />3
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    In Stock
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Adjust
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Tour Poster</TableCell>
                <TableCell>18x24</TableCell>
                <TableCell>Full Color</TableCell>
                <TableCell>42</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <span>15</span>
                    <Badge variant="outline" className="text-green-500 bg-green-50">
                      <ArrowUp className="mr-1 h-3 w-3" />4
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    In Stock
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    Adjust
                  </Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Mark Damaged/Lost</Button>
          <Button>Restock Items</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
