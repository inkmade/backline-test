"use client"

import { CreditCard, DollarSign, Smartphone } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function PaymentProcessingModule() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Payment Processing</h2>
          <p className="text-muted-foreground">Manage payments and view transaction history</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <DollarSign className="mr-2 h-4 w-4" />
            Cash Register
          </Button>
          <Button variant="default">
            <CreditCard className="mr-2 h-4 w-4" />
            Connect Card Reader
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Square</CardTitle>
            <CardDescription>Card reader integration</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="bg-green-50 text-green-700">
                Connected
              </Badge>
              <Button variant="ghost" size="sm">
                Configure
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Stripe</CardTitle>
            <CardDescription>Online payment processing</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="bg-green-50 text-green-700">
                Connected
              </Badge>
              <Button variant="ghost" size="sm">
                Configure
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Shopify POS</CardTitle>
            <CardDescription>Retail point of sale</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="bg-gray-100 text-gray-500">
                Not Connected
              </Badge>
              <Button variant="ghost" size="sm">
                Connect
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Payment Summary</CardTitle>
          <CardDescription>Overview of today's sales by payment method</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Credit Card</span>
                </div>
                <div className="font-medium">$12,456.78</div>
              </div>
              <Progress value={68} className="h-2" />
              <div className="text-xs text-muted-foreground text-right">68% of total sales</div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Cash</span>
                </div>
                <div className="font-medium">$4,023.45</div>
              </div>
              <Progress value={22} className="h-2" />
              <div className="text-xs text-muted-foreground text-right">22% of total sales</div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Mobile Pay</span>
                </div>
                <div className="font-medium">$1,828.84</div>
              </div>
              <Progress value={10} className="h-2" />
              <div className="text-xs text-muted-foreground text-right">10% of total sales</div>
            </div>

            <Separator />

            <div className="flex items-center justify-between font-medium">
              <span>Total Sales</span>
              <span>$18,309.07</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Latest payment transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Time</TableHead>
                <TableHead>Transaction ID</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Payment Method</TableHead>
                <TableHead className="text-right">Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>9:45 PM</TableCell>
                <TableCell>TRX-4829</TableCell>
                <TableCell>Tour Tee (L), Vinyl</TableCell>
                <TableCell>Credit Card</TableCell>
                <TableCell className="text-right">$60.00</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>9:42 PM</TableCell>
                <TableCell>TRX-4828</TableCell>
                <TableCell>Hoodie (M)</TableCell>
                <TableCell>Cash</TableCell>
                <TableCell className="text-right">$55.00</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>9:38 PM</TableCell>
                <TableCell>TRX-4827</TableCell>
                <TableCell>Tour Tee (S), Poster</TableCell>
                <TableCell>Mobile Pay</TableCell>
                <TableCell className="text-right">$55.00</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>9:35 PM</TableCell>
                <TableCell>TRX-4826</TableCell>
                <TableCell>Tour Tee (XL), Hat</TableCell>
                <TableCell>Credit Card</TableCell>
                <TableCell className="text-right">$65.00</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>9:30 PM</TableCell>
                <TableCell>TRX-4825</TableCell>
                <TableCell>Vinyl, Sticker Pack</TableCell>
                <TableCell>Credit Card</TableCell>
                <TableCell className="text-right">$30.00</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button variant="outline" size="sm">
            View All Transactions
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
