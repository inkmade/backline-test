"use client"

import { useState } from "react"
import { ArrowUp, Calendar, CreditCard, DollarSign, Package, ShoppingBag, TrendingUp, Users } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { PaymentProcessingModule } from "@/components/payment-processing-module"
import { InventoryTrackingModule } from "@/components/inventory-tracking-module"
import { TaxCollectionModule } from "@/components/tax-collection-module"
import { ReportingModule } from "@/components/reporting-module"
import { ForecastingModule } from "@/components/forecasting-module"
import { RecentSalesActivity } from "@/components/recent-sales-activity"
import { formatCurrency } from "@/lib/utils"

export default function LiveDashboard({
  currentShow,
  salesData,
  totalSales,
  totalItems,
  topSellingItem,
  inventory,
  upcomingShows,
}) {
  const [activeTab, setActiveTab] = useState("overview")

  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  // Format time for display
  const formatTime = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Tour Dashboard</h2>
          <p className="text-muted-foreground">
            {currentShow
              ? `Current venue: ${currentShow.venue.name}, ${currentShow.venue.city}`
              : "No show scheduled for today"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Calendar className="mr-2 h-4 w-4" />
            {currentShow ? formatDate(currentShow.date) : "No show today"}
          </Button>
          <Button variant="default" size="sm">
            <ShoppingBag className="mr-2 h-4 w-4" />
            Open POS
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalSales)}</div>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-muted-foreground">{currentShow ? "Today's sales" : "No sales data"}</span>
              {currentShow && (
                <Badge variant="outline" className="text-green-500 bg-green-50">
                  <ArrowUp className="mr-1 h-3 w-3" />
                  20.1%
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Items Sold</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalItems}</div>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-muted-foreground">{currentShow ? "Today's sales" : "No sales data"}</span>
              {currentShow && (
                <Badge variant="outline" className="text-green-500 bg-green-50">
                  <ArrowUp className="mr-1 h-3 w-3" />
                  12.5%
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Per-Head Revenue</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {currentShow && totalSales > 0
                ? formatCurrency(totalSales / (currentShow.venue.capacity * 0.8))
                : "$0.00"}
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-muted-foreground">Based on estimated attendance</span>
              {currentShow && (
                <Badge variant="outline" className="text-green-500 bg-green-50">
                  <ArrowUp className="mr-1 h-3 w-3" />
                  5.2%
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Item</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{topSellingItem ? topSellingItem.name : "No data"}</div>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-muted-foreground">
                {topSellingItem ? `${topSellingItem.count} sold today` : "No sales data"}
              </span>
              {topSellingItem && <Badge variant="outline">Hot Item</Badge>}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-6 lg:w-[800px]">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="taxes">Taxes</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="lg:col-span-5">
              <CardHeader>
                <CardTitle>Sales Overview</CardTitle>
                <CardDescription>
                  {currentShow ? `Live sales data for ${currentShow.venue.name}` : "No show scheduled for today"}
                </CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <div className="h-[300px] w-full">
                  {/* This would be a chart component in a real app */}
                  <div className="flex h-full w-full items-center justify-center rounded-md border border-dashed">
                    <div className="flex flex-col items-center gap-2 text-center">
                      <ShoppingBag className="h-8 w-8 text-muted-foreground" />
                      <div className="text-sm font-medium">Sales Chart</div>
                      <div className="text-xs text-muted-foreground">Real-time sales data visualization</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Live sales feed</CardDescription>
              </CardHeader>
              <CardContent>
                <RecentSalesActivity salesData={salesData} />
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Stock Status</CardTitle>
                <CardDescription>Current inventory levels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {inventory && inventory.length > 0 ? (
                    inventory.slice(0, 5).map((item) => {
                      const stockPercentage = Math.round((item.currentStock / item.initialStock) * 100)
                      const itemName = item.variant.item.name
                      const variantName = item.variant.size ? `${itemName} (${item.variant.size})` : itemName

                      return (
                        <div key={item.id} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <div className="font-medium">{variantName}</div>
                            <div className="text-muted-foreground">{stockPercentage}%</div>
                          </div>
                          <Progress value={stockPercentage} className="h-2" />
                        </div>
                      )
                    })
                  ) : (
                    <div className="text-center text-muted-foreground py-4">No inventory data available</div>
                  )}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Breakdown by payment type</CardDescription>
              </CardHeader>
              <CardContent>
                {salesData && salesData.length > 0 ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <CreditCard className="h-5 w-5 text-muted-foreground" />
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="font-medium">Credit Card</div>
                          <div className="text-muted-foreground">68%</div>
                        </div>
                        <Progress value={68} className="h-2" />
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <DollarSign className="h-5 w-5 text-muted-foreground" />
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="font-medium">Cash</div>
                          <div className="text-muted-foreground">22%</div>
                        </div>
                        <Progress value={22} className="h-2" />
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <svg
                        className="h-5 w-5 text-muted-foreground"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <rect width="20" height="14" x="2" y="5" rx="2" />
                        <line x1="2" x2="22" y1="10" y2="10" />
                      </svg>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="font-medium">Mobile Pay</div>
                          <div className="text-muted-foreground">10%</div>
                        </div>
                        <Progress value={10} className="h-2" />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-4">No payment data available</div>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Shows</CardTitle>
                <CardDescription>Next {upcomingShows?.length || 0} tour dates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingShows && upcomingShows.length > 0 ? (
                    upcomingShows.map((show, index) => (
                      <div key={show.id}>
                        <div className="flex items-start gap-4">
                          <div className="rounded-md bg-primary/10 p-2 text-primary">
                            <Calendar className="h-4 w-4" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium">{formatDate(show.date)}</p>
                            <p className="text-xs text-muted-foreground">
                              {show.venue.name}, {show.venue.city}
                            </p>
                            <Badge variant="outline" className="mt-1">
                              Load-in: {formatTime(show.loadInTime)}
                            </Badge>
                          </div>
                        </div>
                        {index < upcomingShows.length - 1 && <Separator className="my-4" />}
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-muted-foreground py-4">No upcoming shows scheduled</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="payments" className="space-y-4">
          <PaymentProcessingModule currentShow={currentShow} salesData={salesData} />
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <InventoryTrackingModule currentShow={currentShow} inventory={inventory} />
        </TabsContent>

        <TabsContent value="taxes" className="space-y-4">
          <TaxCollectionModule currentShow={currentShow} />
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <ReportingModule currentShow={currentShow} />
        </TabsContent>

        <TabsContent value="forecasting" className="space-y-4">
          <ForecastingModule currentShow={currentShow} upcomingShows={upcomingShows} inventory={inventory} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
