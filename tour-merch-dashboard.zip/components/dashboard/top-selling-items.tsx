import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const defaultData = [
  {
    id: "1",
    name: "Tour T-Shirt (L)",
    category: "Apparel",
    sold: 70,
    revenue: "$1,750.00",
    profit: "$1,155.00",
  },
  {
    id: "2",
    name: "Tour Hoodie (M)",
    category: "Apparel",
    sold: 26,
    revenue: "$1,170.00",
    profit: "$702.00",
  },
  {
    id: "3",
    name: "Vinyl Record",
    category: "Music",
    sold: 10,
    revenue: "$250.00",
    profit: "$150.00",
  },
  {
    id: "4",
    name: "Tour Poster",
    category: "Accessories",
    sold: 15,
    revenue: "$300.00",
    profit: "$225.00",
  },
  {
    id: "5",
    name: "Hat",
    category: "Accessories",
    sold: 8,
    revenue: "$240.00",
    profit: "$144.00",
  },
]

export function TopSellingItems({ data = defaultData }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Item</TableHead>
          <TableHead>Category</TableHead>
          <TableHead className="text-right">Sold</TableHead>
          <TableHead className="text-right">Revenue</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.map((item) => (
          <TableRow key={item.id}>
            <TableCell className="font-medium">{item.name}</TableCell>
            <TableCell>{item.category}</TableCell>
            <TableCell className="text-right">{item.sold}</TableCell>
            <TableCell className="text-right">{item.revenue}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
