"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

const defaultData = [
  {
    id: "1",
    name: "T-Shirt + Poster Bundle",
    description: "Get a tour t-shirt and poster at a discount",
    price: 40.0,
    discount: 5.0,
    active: true,
    items: ["Tour T-Shirt", "Tour Poster"],
  },
  {
    id: "2",
    name: "Ultimate Fan Pack",
    description: "T-shirt, vinyl, and poster bundle",
    price: 60.0,
    discount: 10.0,
    active: true,
    items: ["Tour T-Shirt", "Vinyl Record", "Tour Poster"],
  },
]

export function BundleManagement({ data = defaultData }) {
  const [bundles, setBundles] = useState(data)
  const [open, setOpen] = useState(false)

  const toggleActive = (id) => {
    setBundles(bundles.map((bundle) => (bundle.id === id ? { ...bundle, active: !bundle.active } : bundle)))
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between">
        <h3 className="text-lg font-medium">Current Bundles</h3>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>Add Bundle</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Bundle</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input id="name" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Description
                </Label>
                <Input id="description" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="price" className="text-right">
                  Price
                </Label>
                <Input id="price" type="number" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="discount" className="text-right">
                  Discount
                </Label>
                <Input id="discount" type="number" className="col-span-3" />
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={() => setOpen(false)}>Save Bundle</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Items</TableHead>
            <TableHead className="text-right">Price</TableHead>
            <TableHead className="text-right">Discount</TableHead>
            <TableHead className="text-center">Active</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {bundles.map((bundle) => (
            <TableRow key={bundle.id}>
              <TableCell className="font-medium">{bundle.name}</TableCell>
              <TableCell>{bundle.items.join(", ")}</TableCell>
              <TableCell className="text-right">${bundle.price.toFixed(2)}</TableCell>
              <TableCell className="text-right">${bundle.discount.toFixed(2)}</TableCell>
              <TableCell className="text-center">
                <Switch checked={bundle.active} onCheckedChange={() => toggleActive(bundle.id)} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
