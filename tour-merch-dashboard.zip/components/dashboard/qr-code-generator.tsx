"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

export function QRCodeGenerator() {
  const [selectedItem, setSelectedItem] = useState("")
  const [qrGenerated, setQrGenerated] = useState(false)

  const generateQR = () => {
    if (selectedItem) {
      setQrGenerated(true)
    }
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="item-select">Select Item for Self-Checkout</Label>
        <Select value={selectedItem} onValueChange={setSelectedItem}>
          <SelectTrigger id="item-select">
            <SelectValue placeholder="Select an item" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="tshirt-l">Tour T-Shirt (L)</SelectItem>
            <SelectItem value="tshirt-m">Tour T-Shirt (M)</SelectItem>
            <SelectItem value="hoodie-l">Tour Hoodie (L)</SelectItem>
            <SelectItem value="vinyl">Vinyl Record</SelectItem>
            <SelectItem value="poster">Tour Poster</SelectItem>
            <SelectItem value="bundle-1">T-Shirt + Poster Bundle</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button onClick={generateQR} disabled={!selectedItem}>
        Generate QR Code
      </Button>

      {qrGenerated && (
        <Card className="mt-4">
          <CardContent className="p-4 flex flex-col items-center">
            <div className="w-48 h-48 bg-gray-200 flex items-center justify-center border">
              <div className="text-center">
                <div className="w-32 h-32 mx-auto bg-white p-2">
                  {/* Placeholder for QR code */}
                  <div className="w-full h-full border-2 border-black grid grid-cols-4 grid-rows-4">
                    <div className="border-2 border-black col-span-1 row-span-1 m-1"></div>
                    <div className="border-2 border-black col-span-1 row-span-1 col-start-4 m-1"></div>
                    <div className="border-2 border-black col-span-1 row-span-1 row-start-4 m-1"></div>
                    <div className="border-2 border-black col-span-2 row-span-2 col-start-2 row-start-2 m-1"></div>
                  </div>
                </div>
                <p className="mt-2 text-sm">Scan to purchase {selectedItem.replace("-", " ").toUpperCase()}</p>
              </div>
            </div>
            <Button className="mt-4" variant="outline">
              Download QR Code
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
