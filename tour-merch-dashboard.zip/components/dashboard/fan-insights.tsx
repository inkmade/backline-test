"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts"
import { Card, CardContent } from "@/components/ui/card"

const defaultData = {
  demographics: [
    {
      age: "18-24",
      count: 250,
    },
    {
      age: "25-34",
      count: 450,
    },
    {
      age: "35-44",
      count: 350,
    },
    {
      age: "45-54",
      count: 200,
    },
    {
      age: "55+",
      count: 100,
    },
  ],
  locations: [
    {
      location: "San Francisco",
      count: 400,
    },
    {
      location: "Los Angeles",
      count: 300,
    },
    {
      location: "Seattle",
      count: 200,
    },
    {
      location: "Portland",
      count: 150,
    },
    {
      location: "Other",
      count: 300,
    },
  ],
  stats: {
    totalCustomers: 1350,
    repeatCustomers: 320,
    averageSpend: 42.5,
    emailSubscribers: 875,
  },
}

export function FanInsights({ data = defaultData }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-xl font-bold">{data.stats.totalCustomers}</div>
            <p className="text-xs text-muted-foreground">Total Customers</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xl font-bold">${data.stats.averageSpend.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Average Spend</p>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-2">Age Demographics</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data.demographics}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="age" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="count" fill="#8884d8" name="Customers" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-2">Customer Locations</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data.locations}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="location" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="count" fill="#82ca9d" name="Customers" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
