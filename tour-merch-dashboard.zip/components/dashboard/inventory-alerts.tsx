import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

const defaultData = [
  {
    id: "1",
    type: "low_stock",
    item: "Tour T-Shirt (XL)",
    message: "Only 5 left in stock",
    severity: "warning",
  },
  {
    id: "2",
    type: "low_stock",
    item: "Tour Hoodie (L)",
    message: "Only 3 left in stock",
    severity: "warning",
  },
  {
    id: "3",
    type: "out_of_stock",
    item: "Tour T-Shirt (S)",
    message: "Out of stock",
    severity: "error",
  },
]

export function InventoryAlerts({ data = defaultData }) {
  return (
    <div className="space-y-4">
      {data.map((alert) => (
        <Alert key={alert.id} variant={alert.severity === "error" ? "destructive" : "default"}>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{alert.item}</AlertTitle>
          <AlertDescription>{alert.message}</AlertDescription>
        </Alert>
      ))}
    </div>
  )
}
