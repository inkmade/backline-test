import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const defaultData = [
  {
    id: "1",
    name: "Standard Split",
    artist: "80%",
    venue: "15%",
    other: "5%",
    appliesTo: "All shows (default)",
  },
  {
    id: "2",
    name: "LA Special Split",
    artist: "75%",
    venue: "20%",
    other: "5%",
    appliesTo: "Los Angeles shows",
  },
]

export function RevenueSplits({ data = defaultData }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Artist</TableHead>
          <TableHead>Venue</TableHead>
          <TableHead>Other</TableHead>
          <TableHead>Applies To</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.map((split) => (
          <TableRow key={split.id}>
            <TableCell className="font-medium">{split.name}</TableCell>
            <TableCell>{split.artist}</TableCell>
            <TableCell>{split.venue}</TableCell>
            <TableCell>{split.other}</TableCell>
            <TableCell>{split.appliesTo}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
