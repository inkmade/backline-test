"use client"

import { useState } from "react"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { ModeToggle } from "@/components/mode-toggle"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Overview } from "@/components/dashboard/overview"
import { RecentSales } from "@/components/dashboard/recent-sales"
import { InventoryOverview } from "@/components/dashboard/inventory-overview"
import { TourSchedule } from "@/components/dashboard/tour-schedule"
import { Search } from "@/components/search"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarDateRangePicker } from "@/components/date-range-picker"
import { SalesMetrics } from "@/components/dashboard/sales-metrics"
import { TopSellingItems } from "@/components/dashboard/top-selling-items"
import { SalesByLocation } from "@/components/dashboard/sales-by-location"
import { SalesByPaymentMethod } from "@/components/dashboard/sales-by-payment-method"
import { InventoryAlerts } from "@/components/dashboard/inventory-alerts"
import { RevenueSplits } from "@/components/dashboard/revenue-splits"
import { BundleManagement } from "@/components/dashboard/bundle-management"
import { QRCodeGenerator } from "@/components/dashboard/qr-code-generator"
import { FanInsights } from "@/components/dashboard/fan-insights"

export default function DashboardPage({ data }: { data: any }) {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="flex min-h-screen flex-col">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <Search />
            <ModeToggle />
            <UserNav />
          </div>
        </div>
      </div>
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <div className="flex items-center space-x-2">
            <CalendarDateRangePicker />
            <Button>Download</Button>
          </div>
        </div>
        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="sales">Sales</TabsTrigger>
            <TabsTrigger value="tours">Tours</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${data?.totalRevenue?.toLocaleString() || "24,567"}</div>
                  <p className="text-xs text-muted-foreground">+{data?.revenueIncrease || "20.1"}% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sales</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <rect width="20" height="14" x="2" y="5" rx="2" />
                    <path d="M2 10h20" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{data?.totalSales || "1,234"}</div>
                  <p className="text-xs text-muted-foreground">+{data?.salesIncrease || "15.2"}% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Tours</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{data?.activeTours || "2"}</div>
                  <p className="text-xs text-muted-foreground">{data?.upcomingShows || "5"} upcoming shows</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${data?.inventoryValue?.toLocaleString() || "42,500"}</div>
                  <p className="text-xs text-muted-foreground">{data?.lowStockItems || "3"} items low on stock</p>
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Overview</CardTitle>
                </CardHeader>
                <CardContent className="pl-2">
                  <Overview data={data?.overviewData} />
                </CardContent>
              </Card>
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Recent Sales</CardTitle>
                  <CardDescription>{data?.recentSalesCount || "5"} sales today</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecentSales data={data?.recentSales} />
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Top Selling Items</CardTitle>
                  <CardDescription>Your best performing merchandise</CardDescription>
                </CardHeader>
                <CardContent>
                  <TopSellingItems data={data?.topSellingItems} />
                </CardContent>
              </Card>
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Tour Schedule</CardTitle>
                  <CardDescription>Upcoming shows and venues</CardDescription>
                </CardHeader>
                <CardContent>
                  <TourSchedule data={data?.tourSchedule} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="inventory" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="col-span-2">
                <CardHeader>
                  <CardTitle>Inventory Overview</CardTitle>
                  <CardDescription>Current stock levels across all items</CardDescription>
                </CardHeader>
                <CardContent>
                  <InventoryOverview data={data?.inventoryData} />
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Inventory Alerts</CardTitle>
                  <CardDescription>Items that need attention</CardDescription>
                </CardHeader>
                <CardContent>
                  <InventoryAlerts data={data?.inventoryAlerts} />
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Bundle Management</CardTitle>
                  <CardDescription>Create and manage merchandise bundles</CardDescription>
                </CardHeader>
                <CardContent>
                  <BundleManagement data={data?.bundleData} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="sales" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Sales Metrics</CardTitle>
                  <CardDescription>Key performance indicators</CardDescription>
                </CardHeader>
                <CardContent>
                  <SalesMetrics data={data?.salesMetrics} />
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Sales by Location</CardTitle>
                  <CardDescription>Revenue breakdown by venue</CardDescription>
                </CardHeader>
                <CardContent>
                  <SalesByLocation data={data?.salesByLocation} />
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Payment Methods</CardTitle>
                  <CardDescription>Sales by payment type</CardDescription>
                </CardHeader>
                <CardContent>
                  <SalesByPaymentMethod data={data?.salesByPaymentMethod} />
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>QR Self-Checkout</CardTitle>
                  <CardDescription>Generate QR codes for self-checkout</CardDescription>
                </CardHeader>
                <CardContent>
                  <QRCodeGenerator />
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Fan Insights</CardTitle>
                  <CardDescription>Customer data and analytics</CardDescription>
                </CardHeader>
                <CardContent>
                  <FanInsights data={data?.fanInsights} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="tours" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="col-span-2">
                <CardHeader>
                  <CardTitle>Tour Schedule</CardTitle>
                  <CardDescription>Upcoming shows and venues</CardDescription>
                </CardHeader>
                <CardContent>
                  <TourSchedule data={data?.tourSchedule} />
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Splits</CardTitle>
                  <CardDescription>Manage revenue sharing</CardDescription>
                </CardHeader>
                <CardContent>
                  <RevenueSplits data={data?.revenueSplits} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Settings</CardTitle>
                <CardDescription>Manage your account settings and preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Profile</h3>
                  <p className="text-sm text-muted-foreground">Update your account information and preferences</p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Tax Settings</h3>
                  <p className="text-sm text-muted-foreground">Configure tax rates for different locations</p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Revenue Splits</h3>
                  <p className="text-sm text-muted-foreground">
                    Set up revenue sharing between artists, venues, and other parties
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">User Management</h3>
                  <p className="text-sm text-muted-foreground">Add and manage users with different access levels</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
