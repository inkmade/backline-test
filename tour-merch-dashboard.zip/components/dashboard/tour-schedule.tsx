import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

const defaultData = [
  {
    id: "1",
    date: "May 12, 2025",
    venue: "The Fillmore",
    location: "San Francisco, CA",
    status: "upcoming",
    ticketsSold: "1,150 / 1,150",
    soldOut: true,
  },
  {
    id: "2",
    date: "May 14, 2025",
    venue: "The Warfield",
    location: "San Francisco, CA",
    status: "upcoming",
    ticketsSold: "2,100 / 2,300",
    soldOut: false,
  },
  {
    id: "3",
    date: "May 16, 2025",
    venue: "The Wiltern",
    location: "Los Angeles, CA",
    status: "upcoming",
    ticketsSold: "1,750 / 1,850",
    soldOut: false,
  },
  {
    id: "4",
    date: "May 18, 2025",
    venue: "The Observatory",
    location: "Santa Ana, CA",
    status: "upcoming",
    ticketsSold: "950 / 1,000",
    soldOut: false,
  },
  {
    id: "5",
    date: "May 21, 2025",
    venue: "The Paramount",
    location: "Seattle, WA",
    status: "upcoming",
    ticketsSold: "2,500 / 2,800",
    soldOut: false,
  },
]

export function TourSchedule({ data = defaultData }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Date</TableHead>
          <TableHead>Venue</TableHead>
          <TableHead>Location</TableHead>
          <TableHead>Tickets</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.map((show) => (
          <TableRow key={show.id}>
            <TableCell className="font-medium">{show.date}</TableCell>
            <TableCell>{show.venue}</TableCell>
            <TableCell>{show.location}</TableCell>
            <TableCell>{show.ticketsSold}</TableCell>
            <TableCell>
              {show.soldOut ? (
                <Badge className="bg-red-500">Sold Out</Badge>
              ) : (
                <Badge className="bg-green-500">On Sale</Badge>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
