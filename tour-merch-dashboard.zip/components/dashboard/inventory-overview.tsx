"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from "recharts"

const defaultData = [
  {
    name: "T-Shirts",
    inStock: 180,
    sold: 70,
  },
  {
    name: "Hoodies",
    inStock: 120,
    sold: 26,
  },
  {
    name: "Vinyl",
    inStock: 90,
    sold: 10,
  },
  {
    name: "Posters",
    inStock: 60,
    sold: 15,
  },
  {
    name: "Hats",
    inStock: 42,
    sold: 8,
  },
  {
    name: "Stickers",
    inStock: 85,
    sold: 15,
  },
]

export function InventoryOverview({ data = defaultData }) {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="inStock" fill="#8884d8" name="In Stock" />
        <Bar dataKey="sold" fill="#82ca9d" name="Sold" />
      </BarChart>
    </ResponsiveContainer>
  )
}
