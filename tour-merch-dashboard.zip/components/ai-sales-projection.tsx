"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Brain, Download, RefreshCw, Truck, AlertCircle, Users } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { formatCurrency } from "@/lib/utils"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart as RechartsBarChart,
  Bar,
  Cell,
  Legend,
  PieChart,
  Pie,
} from "recharts"

export function AISalesProjection({ tourId }) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [initialLoading, setInitialLoading] = useState(true)
  const [tourData, setTourData] = useState(null)
  const [projection, setProjection] = useState(null)
  const [selectedTour, setSelectedTour] = useState(tourId || "")
  const [tours, setTours] = useState([])
  const [activeTab, setActiveTab] = useState("overview")
  const [error, setError] = useState("")
  const [selectedSeller, setSelectedSeller] = useState("all")

  // Fetch available tours
  useEffect(() => {
    async function fetchTours() {
      try {
        const response = await fetch("/api/tours?upcoming=true")
        const data = await response.json()
        setTours(data)

        if (data.length > 0 && !tourId) {
          setSelectedTour(data[0].id)
        }
      } catch (error) {
        console.error("Error fetching tours:", error)
        setError("Failed to load tours. Please try again.")
      }
    }

    fetchTours()
  }, [tourId])

  // Fetch tour data when tour is selected
  useEffect(() => {
    async function fetchTourData() {
      if (!selectedTour) return

      setInitialLoading(true)
      try {
        const response = await fetch(`/api/tours/${selectedTour}/projection-data`)
        const data = await response.json()
        setTourData(data)
      } catch (error) {
        console.error("Error fetching tour data:", error)
        setError("Failed to load tour data. Please try again.")
      } finally {
        setInitialLoading(false)
      }
    }

    fetchTourData()
  }, [selectedTour])

  // Generate projection
  const generateProjection = async () => {
    if (!tourData) return

    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/ai/sales-projection", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(tourData),
      })

      if (!response.ok) {
        throw new Error("Failed to generate projection")
      }

      const data = await response.json()
      setProjection(data)
    } catch (error) {
      console.error("Error generating projection:", error)
      setError("Failed to generate AI projection. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  // Handle tour change
  const handleTourChange = (tourId) => {
    setSelectedTour(tourId)
    setProjection(null)
    router.push(`/ai-projection?tourId=${tourId}`)
  }

  // Export projection as CSV
  const exportProjection = () => {
    if (!projection) return

    // Create CSV content
    let csv = "Category,Projected Units,Projected Revenue,Confidence Level\n"

    projection.projections.categories.forEach((category) => {
      csv += `${category.category},${category.projectedUnits},${category.projectedRevenue},${category.confidenceLevel}\n`
    })

    csv += "\nItem,Size,Projected Units,Projected Revenue,Confidence Level\n"

    projection.projections.items.forEach((item) => {
      csv += `${item.item},${item.size || "N/A"},${item.projectedUnits},${item.projectedRevenue},${item.confidenceLevel}\n`
    })

    csv += "\nRestock Recommendations\n"
    csv += "Item,Size,Current Stock,Recommended Restock,Priority,Restock By,Reason\n"

    projection.restockRecommendations.forEach((item) => {
      csv += `${item.item},${item.size || "N/A"},${item.currentStock},${item.recommendedRestock},${item.priority},${item.restockBy},${item.reason}\n`
    })

    // Add seller insights
    csv += "\nSeller Insights\n"
    csv += "Seller,Projected Sales,Projected Revenue,Top Categories\n"

    projection.sellerInsights.forEach((seller) => {
      csv += `${seller.sellerName},${seller.projectedSales},${seller.projectedRevenue},${seller.topCategories.join(";")}\n`
    })

    // Create and download the file
    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.setAttribute("hidden", "")
    a.setAttribute("href", url)
    a.setAttribute("download", `tour-projection-${new Date().toISOString().split("T")[0]}.csv`)
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }

  // Generate purchase orders
  const generatePurchaseOrders = () => {
    if (!projection) return

    // In a real application, this would create purchase orders in the system
    alert("Purchase orders generated for recommended restocks!")
  }

  if (initialLoading) {
    return <ProjectionSkeleton />
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">AI Merchandise Projections</h2>
          <p className="text-muted-foreground">Powered by Grok AI</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedTour} onValueChange={handleTourChange}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select tour" />
            </SelectTrigger>
            <SelectContent>
              {tours.map((tour) => (
                <SelectItem key={tour.id} value={tour.id}>
                  {tour.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => setProjection(null)} disabled={loading || !projection}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Reset
          </Button>
          <Button variant="default" onClick={generateProjection} disabled={loading || !tourData}>
            <Brain className="mr-2 h-4 w-4" />
            {loading ? "Generating..." : "Generate Projection"}
          </Button>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!tourData && !initialLoading && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>No Tour Selected</AlertTitle>
          <AlertDescription>Please select a tour to generate sales projections.</AlertDescription>
        </Alert>
      )}

      {tourData && !projection && !loading && (
        <Card>
          <CardHeader>
            <CardTitle>Generate AI Sales Projection</CardTitle>
            <CardDescription>
              Use Grok AI to analyze your tour data and predict future merchandise sales
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h3 className="text-lg font-medium mb-2">Tour Information</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Remaining Shows:</span>
                    <span className="font-medium">{tourData.remainingShows}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Ticket Sales:</span>
                    <span className="font-medium">{tourData.totalTicketSales.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Average Attendance:</span>
                    <span className="font-medium">{Math.round(tourData.averageAttendance).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Venue Types:</span>
                    <span className="font-medium">{tourData.venueTypes.join(", ")}</span>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Inventory Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Items:</span>
                    <span className="font-medium">
                      {tourData.currentInventory.reduce((sum, item) => sum + item.currentStock, 0).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Categories:</span>
                    <span className="font-medium">{tourData.inventoryAggregates.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Low Stock Items:</span>
                    <span className="font-medium text-amber-500">
                      {tourData.inventoryAlerts.filter((item) => item.alertType === "Low Stock").length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Out of Stock Items:</span>
                    <span className="font-medium text-red-500">
                      {tourData.inventoryAlerts.filter((item) => item.alertType === "Out of Stock").length}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4">
              <h3 className="text-lg font-medium mb-2">What Grok AI Will Analyze</h3>
              <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                <li>Past sales data across {tourData.pastSalesData.length} transactions</li>
                <li>Current inventory levels for {tourData.currentInventory.length} items</li>
                <li>Venue sizes and demographics for upcoming shows</li>
                <li>Seller performance data from {tourData.sellerPerformance.length} team members</li>
                <li>Inventory alerts and stock levels</li>
                <li>Seasonal trends and merchandise popularity</li>
              </ul>
            </div>

            <div className="pt-4">
              <h3 className="text-lg font-medium mb-2">What You'll Get</h3>
              <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                <li>Projected sales for each merchandise category</li>
                <li>Item-level sales predictions</li>
                <li>Restock recommendations with priorities and deadlines</li>
                <li>Revenue forecasts and insights</li>
                <li>Seller-specific performance projections</li>
                <li>Venue-specific sales strategies</li>
                <li>Optimization suggestions for inventory management</li>
              </ul>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={generateProjection} disabled={loading}>
              <Brain className="mr-2 h-4 w-4" />
              {loading ? "Generating..." : "Generate AI Projection"}
            </Button>
          </CardFooter>
        </Card>
      )}

      {loading && (
        <Card>
          <CardHeader>
            <CardTitle>Generating Projection</CardTitle>
            <CardDescription>Grok AI is analyzing your tour data and generating sales projections...</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <div className="w-full max-w-md">
              <Progress value={45} className="h-2 mb-4" />
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>Analyzing past sales</span>
                <span>45%</span>
              </div>
            </div>
            <div className="mt-8 flex items-center justify-center">
              <Brain className="h-12 w-12 text-primary animate-pulse" />
            </div>
          </CardContent>
        </Card>
      )}

      {projection && (
        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 lg:w-[800px]">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="items">Items</TabsTrigger>
            <TabsTrigger value="restock">Restock</TabsTrigger>
            <TabsTrigger value="sellers">Sellers</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Projected Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(projection.totalProjectedRevenue)}</div>
                  <p className="text-xs text-muted-foreground">For remaining {tourData.remainingShows} shows</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Per-Show Average</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(projection.totalProjectedRevenue / tourData.remainingShows)}
                  </div>
                  <p className="text-xs text-muted-foreground">Average revenue per show</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Top Category</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {
                      projection.projections.categories.sort((a, b) => b.projectedRevenue - a.projectedRevenue)[0]
                        .category
                    }
                  </div>
                  <p className="text-xs text-muted-foreground">Highest projected revenue</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Restock Items</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{projection.restockRecommendations.length}</div>
                  <p className="text-xs text-muted-foreground">
                    {projection.restockRecommendations.filter((r) => r.priority === "High").length} high priority
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Inventory Status</CardTitle>
                  <CardDescription>Current inventory levels by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {tourData.inventoryAggregates.map((category) => (
                      <div key={category.category} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{category.category}</span>
                          <span className="text-sm text-muted-foreground">
                            {category.totalCurrentStock} / {category.totalInitialStock} items
                          </span>
                        </div>
                        <Progress
                          value={category.stockPercentage}
                          className={`h-2 ${
                            category.stockPercentage < 20
                              ? "bg-red-100"
                              : category.stockPercentage < 50
                                ? "bg-amber-100"
                                : "bg-green-100"
                          }`}
                        />
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Sold: {category.totalSold}</span>
                          <span>Damaged/Lost: {category.totalDamaged + category.totalLost}</span>
                          <span>{category.stockPercentage}% remaining</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Venue Projections</CardTitle>
                  <CardDescription>Sales projections by venue type</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Venue Type</TableHead>
                        <TableHead>Units/Show</TableHead>
                        <TableHead>Revenue/Show</TableHead>
                        <TableHead>Top Categories</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {projection.projections.venues.map((venue) => (
                        <TableRow key={venue.venueType}>
                          <TableCell className="font-medium">{venue.venueType}</TableCell>
                          <TableCell>{venue.projectedUnitsPerShow}</TableCell>
                          <TableCell>{formatCurrency(venue.projectedRevenuePerShow)}</TableCell>
                          <TableCell>{venue.topCategories.slice(0, 2).join(", ")}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>AI Insights</CardTitle>
                <CardDescription>Key insights from Grok AI analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {projection.insights.map((insight, index) => (
                    <Alert key={index} className="bg-primary/5 border-primary/20">
                      <Brain className="h-4 w-4 text-primary" />
                      <AlertDescription>{insight}</AlertDescription>
                    </Alert>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recommendations</CardTitle>
                <CardDescription>Actionable recommendations to optimize sales</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {projection.recommendations.map((recommendation, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className="mt-0.5 rounded-full bg-primary/10 p-1">
                        <div className="h-2 w-2 rounded-full bg-primary" />
                      </div>
                      <p>{recommendation}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={exportProjection}>
                  <Download className="mr-2 h-4 w-4" />
                  Export Projection
                </Button>
                <Button onClick={generatePurchaseOrders}>
                  <Truck className="mr-2 h-4 w-4" />
                  Generate Purchase Orders
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="categories" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Category Projections</CardTitle>
                <CardDescription>Projected sales by merchandise category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart
                      data={projection.projections.categories}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="category" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip
                        formatter={(value, name) => {
                          if (name === "projectedUnits") return [value, "Units"]
                          if (name === "projectedRevenue") return [`$${value}`, "Revenue"]
                          return [value, name]
                        }}
                      />
                      <Legend />
                      <Bar yAxisId="left" dataKey="projectedUnits" fill="#8884d8" name="Units" />
                      <Bar yAxisId="right" dataKey="projectedRevenue" fill="#82ca9d" name="Revenue" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Category Breakdown</CardTitle>
                <CardDescription>Detailed projections by category</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Category</TableHead>
                      <TableHead>Projected Units</TableHead>
                      <TableHead>Projected Revenue</TableHead>
                      <TableHead>Confidence</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projection.projections.categories.map((category, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{category.category}</TableCell>
                        <TableCell>{category.projectedUnits.toLocaleString()}</TableCell>
                        <TableCell>{formatCurrency(category.projectedRevenue)}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              category.confidenceLevel === "High"
                                ? "bg-green-500"
                                : category.confidenceLevel === "Medium"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }
                          >
                            {category.confidenceLevel}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="items" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Top Items by Projected Revenue</CardTitle>
                <CardDescription>Highest revenue generating items</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={projection.projections.items
                          .sort((a, b) => b.projectedRevenue - a.projectedRevenue)
                          .slice(0, 5)}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="projectedRevenue"
                        nameKey="item"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {projection.projections.items.slice(0, 5).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={`hsl(${index * 45}, 70%, 60%)`} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`$${value}`, "Revenue"]} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center">
                <div className="flex-1">
                  <CardTitle>Item Projections</CardTitle>
                  <CardDescription>Detailed projections by item</CardDescription>
                </div>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {Array.from(
                      new Set(projection.projections.items.map((item) => item.category || "Uncategorized")),
                    ).map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Projected Units</TableHead>
                      <TableHead>Projected Revenue</TableHead>
                      <TableHead>Confidence</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projection.projections.items.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{item.item}</TableCell>
                        <TableCell>{item.size || "N/A"}</TableCell>
                        <TableCell>{item.projectedUnits.toLocaleString()}</TableCell>
                        <TableCell>{formatCurrency(item.projectedRevenue)}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              item.confidenceLevel === "High"
                                ? "bg-green-500"
                                : item.confidenceLevel === "Medium"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }
                          >
                            {item.confidenceLevel}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="restock" className="space-y-4">
            <Alert className="bg-primary/5 border-primary/20">
              <Brain className="h-4 w-4 text-primary" />
              <AlertTitle>AI Restock Recommendation</AlertTitle>
              <AlertDescription>
                Based on projected sales, you should place restock orders for {projection.restockRecommendations.length}{" "}
                items.
                {projection.restockRecommendations.filter((r) => r.priority === "High").length} items are high priority
                and should be ordered immediately.
              </AlertDescription>
            </Alert>

            <Card>
              <CardHeader>
                <CardTitle>Restock Recommendations</CardTitle>
                <CardDescription>Items that need to be restocked based on projections</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Current Stock</TableHead>
                      <TableHead>Recommended Restock</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Restock By</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projection.restockRecommendations.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{item.item}</TableCell>
                        <TableCell>{item.size || "N/A"}</TableCell>
                        <TableCell>{item.currentStock}</TableCell>
                        <TableCell>{item.recommendedRestock}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              item.priority === "High"
                                ? "bg-red-500"
                                : item.priority === "Medium"
                                  ? "bg-yellow-500"
                                  : "bg-green-500"
                            }
                          >
                            {item.priority}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(item.restockBy).toLocaleDateString()}</TableCell>
                        <TableCell className="max-w-[200px] truncate" title={item.reason}>
                          {item.reason}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Order
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export Restock List
                </Button>
                <Button>
                  <Truck className="mr-2 h-4 w-4" />
                  Order All Items
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="sellers" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center">
                <div className="flex-1">
                  <CardTitle>Seller Performance Projections</CardTitle>
                  <CardDescription>AI-generated insights for each team member</CardDescription>
                </div>
                <Select value={selectedSeller} onValueChange={setSelectedSeller}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select seller" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sellers</SelectItem>
                    {projection.sellerInsights.map((seller) => (
                      <SelectItem key={seller.sellerId} value={seller.sellerId}>
                        {seller.sellerName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {projection.sellerInsights
                    .filter((seller) => selectedSeller === "all" || seller.sellerId === selectedSeller)
                    .map((seller) => (
                      <Card key={seller.sellerId} className="overflow-hidden">
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback>{seller.sellerName.slice(0, 2).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div>
                              <CardTitle className="text-base">{seller.sellerName}</CardTitle>
                              <CardDescription>
                                Projected Sales: {formatCurrency(seller.projectedRevenue)}
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="space-y-2">
                            <div>
                              <h4 className="text-sm font-medium mb-1">Top Categories</h4>
                              <div className="flex flex-wrap gap-1">
                                {seller.topCategories.map((category, i) => (
                                  <Badge key={i} variant="outline">
                                    {category}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium mb-1">AI Insights</h4>
                              <ul className="text-sm space-y-1">
                                {seller.insights.map((insight, i) => (
                                  <li key={i} className="text-muted-foreground">
                                    • {insight}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="border-t bg-muted/50 px-6 py-3">
                          <div className="flex items-center justify-between w-full text-xs">
                            <span>Projected Units: {seller.projectedSales}</span>
                            <Button variant="ghost" size="sm" className="h-7 px-2">
                              View Details
                            </Button>
                          </div>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </CardContent>
            </Card>

            {selectedSeller !== "all" && (
              <Card>
                <CardHeader>
                  <CardTitle>Seller Recommendations</CardTitle>
                  <CardDescription>
                    Personalized recommendations for{" "}
                    {projection.sellerInsights.find((s) => s.sellerId === selectedSeller)?.sellerName}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {projection.sellerInsights
                      .find((s) => s.sellerId === selectedSeller)
                      ?.recommendations.map((recommendation, index) => (
                        <Alert key={index} className="bg-primary/5 border-primary/20">
                          <Users className="h-4 w-4 text-primary" />
                          <AlertDescription>{recommendation}</AlertDescription>
                        </Alert>
                      ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

function ProjectionSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <Skeleton className="h-8 w-64" />
          <Skeleton className="mt-2 h-4 w-40" />
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className="h-10 w-[200px]" />
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-10 w-40" />
        </div>
      </div>

      <Skeleton className="h-[400px]" />
    </div>
  )
}
