"use server"

import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { auth } from "@/lib/auth-utils"

// Create a new bundle
const bundleItemSchema = z.object({
  itemId: z.string().min(1, "Item ID is required"),
  quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
})

const bundleSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  description: z.string().optional(),
  price: z.coerce.number().min(0, "Price must be a positive number"),
  discount: z.coerce.number().min(0, "Discount must be a positive number"),
  active: z.boolean().default(true),
  items: z.array(bundleItemSchema).min(1, "At least one item is required"),
})

export async function createBundle(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "TOUR_MANAGER"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    // Parse the items JSON string from the form data
    const itemsJson = formData.get("items") as string
    const items = JSON.parse(itemsJson)

    const validatedFields = bundleSchema.parse({
      name: formData.get("name"),
      description: formData.get("description"),
      price: formData.get("price"),
      discount: formData.get("discount"),
      active: formData.get("active") === "true",
      items,
    })

    const { name, description, price, discount, active, items: bundleItems } = validatedFields

    const bundle = await prisma.bundle.create({
      data: {
        name,
        description,
        price,
        discount,
        active,
        items: {
          create: bundleItems.map((item: any) => ({
            itemId: item.itemId,
            quantity: item.quantity,
          })),
        },
      },
      include: {
        items: {
          include: {
            item: true,
          },
        },
      },
    })

    revalidatePath("/bundles")
    return { success: true, bundle }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}
