"use server"

import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { auth } from "@/lib/auth-utils"
import { PaymentMethod, PaymentStatus } from "@prisma/client"

// Create a new sale
const saleItemSchema = z.object({
  variantId: z.string().min(1, "Variant ID is required"),
  quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
  unitPrice: z.coerce.number().min(0, "Unit price must be a positive number"),
})

const saleSchema = z.object({
  showId: z.string().min(1, "Show ID is required"),
  items: z.array(saleItemSchema).min(1, "At least one item is required"),
  paymentMethod: z.enum([PaymentMethod.CREDIT_CARD, PaymentMethod.CASH, PaymentMethod.MOBILE_PAY]),
  customerEmail: z.string().email("Invalid email address").optional().or(z.literal("")),
  customerZip: z.string().optional().or(z.literal("")),
})

export async function createSale(formData: FormData) {
  try {
    const session = await auth()
    if (!session) {
      return { error: "Unauthorized" }
    }

    // Parse the items JSON string from the form data
    const itemsJson = formData.get("items") as string
    const items = JSON.parse(itemsJson)

    const validatedFields = saleSchema.parse({
      showId: formData.get("showId"),
      items: items,
      paymentMethod: formData.get("paymentMethod"),
      customerEmail: formData.get("customerEmail"),
      customerZip: formData.get("customerZip"),
    })

    const { showId, items: saleItems, paymentMethod, customerEmail, customerZip } = validatedFields

    // Get the tax rate for the show
    const taxRate = await prisma.taxRate.findUnique({
      where: { showId },
    })

    // Calculate subtotal
    const subtotal = saleItems.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0)

    // Calculate tax amount
    const taxAmount = taxRate ? subtotal * (taxRate.totalRate / 100) : 0

    // Calculate total
    const total = subtotal + taxAmount

    // Create the sale
    const sale = await prisma.sale.create({
      data: {
        showId,
        sellerId: session.user.id,
        subtotal,
        taxAmount,
        total,
        paymentMethod,
        paymentStatus: PaymentStatus.COMPLETED,
        customerEmail: customerEmail || null,
        customerZip: customerZip || null,
        items: {
          create: saleItems.map((item: any) => ({
            variantId: item.variantId,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            totalPrice: item.unitPrice * item.quantity,
          })),
        },
      },
      include: {
        items: true,
      },
    })

    // Update inventory
    for (const item of saleItems) {
      const inventory = await prisma.showInventory.findFirst({
        where: {
          showId,
          variantId: item.variantId,
        },
      })

      if (inventory) {
        await prisma.showInventory.update({
          where: { id: inventory.id },
          data: {
            currentStock: inventory.currentStock - item.quantity,
            soldCount: inventory.soldCount + item.quantity,
          },
        })
      }
    }

    revalidatePath("/sales")
    return { success: true, sale }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}
