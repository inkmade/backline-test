"use server"

import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { auth } from "@/lib/auth-utils"

// Create a new revenue split
const revenueSplitSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  description: z.string().optional(),
  tourId: z.string().optional(),
  showId: z.string().optional(),
  artistShare: z.coerce.number().min(0, "Artist share must be a positive number"),
  venueShare: z.coerce.number().min(0, "Venue share must be a positive number"),
  otherShare: z.coerce.number().min(0, "Other share must be a positive number"),
})

export async function createRevenueSplit(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "ARTIST", "TOUR_MANAGER"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    const validatedFields = revenueSplitSchema.parse({
      name: formData.get("name"),
      description: formData.get("description"),
      tourId: formData.get("tourId") || undefined,
      showId: formData.get("showId") || undefined,
      artistShare: formData.get("artistShare"),
      venueShare: formData.get("venueShare"),
      otherShare: formData.get("otherShare"),
    })

    // Validate that shares add up to 100%
    const { artistShare, venueShare, otherShare } = validatedFields
    const totalShare = artistShare + venueShare + otherShare

    if (totalShare !== 100) {
      return { error: "Shares must add up to 100%" }
    }

    const revenueSplit = await prisma.revenueSplit.create({
      data: validatedFields,
    })

    revalidatePath("/revenue-splits")
    return { success: true, revenueSplit }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}
