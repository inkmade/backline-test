"use server"

import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { auth } from "@/lib/auth-utils"

// Create a new tour
const tourSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  startDate: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid start date",
  }),
  endDate: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid end date",
  }),
  description: z.string().optional(),
  managerIds: z.array(z.string()).optional(),
})

export async function createTour(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "ARTIST"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    // Parse the manager IDs JSON string from the form data
    const managerIdsJson = formData.get("managerIds") as string
    const managerIds = managerIdsJson ? JSON.parse(managerIdsJson) : []

    const validatedFields = tourSchema.parse({
      name: formData.get("name"),
      startDate: formData.get("startDate"),
      endDate: formData.get("endDate"),
      description: formData.get("description"),
      managerIds,
    })

    const { name, startDate, endDate, description, managerIds: validatedManagerIds } = validatedFields

    const tour = await prisma.tour.create({
      data: {
        name,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        description,
        managers: {
          connect: [
            { id: session.user.id }, // Add the creator as a manager
            ...(validatedManagerIds?.map((id) => ({ id })) || []),
          ],
        },
      },
      include: {
        managers: true,
      },
    })

    revalidatePath("/tours")
    return { success: true, tour }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}

// Create a new show
const showSchema = z.object({
  tourId: z.string().min(1, "Tour ID is required"),
  venueId: z.string().min(1, "Venue ID is required"),
  date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid date",
  }),
  loadInTime: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid load-in time",
  }),
  doorsTime: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid doors time",
  }),
  showTime: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid show time",
  }),
  notes: z.string().optional(),
})

export async function createShow(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "ARTIST", "TOUR_MANAGER"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    const validatedFields = showSchema.parse({
      tourId: formData.get("tourId"),
      venueId: formData.get("venueId"),
      date: formData.get("date"),
      loadInTime: formData.get("loadInTime"),
      doorsTime: formData.get("doorsTime"),
      showTime: formData.get("showTime"),
      notes: formData.get("notes"),
    })

    const { tourId, venueId, date, loadInTime, doorsTime, showTime, notes } = validatedFields

    const show = await prisma.show.create({
      data: {
        tourId,
        venueId,
        date: new Date(date),
        loadInTime: new Date(loadInTime),
        doorsTime: new Date(doorsTime),
        showTime: new Date(showTime),
        notes,
      },
      include: {
        venue: true,
      },
    })

    revalidatePath("/tours")
    return { success: true, show }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}

// Create a new venue
const venueSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  address: z.string().min(1, "Address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  zipCode: z.string().min(1, "Zip code is required"),
  country: z.string().min(1, "Country is required"),
  capacity: z.coerce.number().min(1, "Capacity must be at least 1"),
  contactName: z.string().optional(),
  contactEmail: z.string().email("Invalid email address").optional().or(z.literal("")),
  contactPhone: z.string().optional(),
  notes: z.string().optional(),
})

export async function createVenue(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "ARTIST", "TOUR_MANAGER"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    const validatedFields = venueSchema.parse({
      name: formData.get("name"),
      address: formData.get("address"),
      city: formData.get("city"),
      state: formData.get("state"),
      zipCode: formData.get("zipCode"),
      country: formData.get("country"),
      capacity: formData.get("capacity"),
      contactName: formData.get("contactName"),
      contactEmail: formData.get("contactEmail"),
      contactPhone: formData.get("contactPhone"),
      notes: formData.get("notes"),
    })

    const venue = await prisma.venue.create({
      data: validatedFields,
    })

    revalidatePath("/venues")
    return { success: true, venue }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}
