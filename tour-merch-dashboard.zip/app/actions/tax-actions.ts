"use server"

import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { auth } from "@/lib/auth-utils"

// Create or update tax rate
const taxRateSchema = z.object({
  showId: z.string().min(1, "Show ID is required"),
  stateTax: z.coerce.number().min(0, "State tax must be a positive number"),
  cityTax: z.coerce.number().min(0, "City tax must be a positive number"),
  districtTax: z.coerce.number().min(0, "District tax must be a positive number"),
  taxInclusive: z.boolean().default(false),
})

export async function updateTaxRate(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "TOUR_MANAGER"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    const validatedFields = taxRateSchema.parse({
      showId: formData.get("showId"),
      stateTax: formData.get("stateTax"),
      cityTax: formData.get("cityTax"),
      districtTax: formData.get("districtTax"),
      taxInclusive: formData.get("taxInclusive") === "true",
    })

    const { showId, stateTax, cityTax, districtTax, taxInclusive } = validatedFields
    const totalRate = stateTax + cityTax + districtTax

    // Check if tax rate exists
    const existingTaxRate = await prisma.taxRate.findUnique({
      where: { showId },
    })

    let taxRate
    if (existingTaxRate) {
      // Update existing record
      taxRate = await prisma.taxRate.update({
        where: { id: existingTaxRate.id },
        data: {
          stateTax,
          cityTax,
          districtTax,
          totalRate,
          taxInclusive,
        },
      })
    } else {
      // Create new record
      taxRate = await prisma.taxRate.create({
        data: {
          showId,
          stateTax,
          cityTax,
          districtTax,
          totalRate,
          taxInclusive,
        },
      })
    }

    revalidatePath("/taxes")
    return { success: true, taxRate }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}
