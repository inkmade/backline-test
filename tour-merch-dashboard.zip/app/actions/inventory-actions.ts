"use server"

import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { auth } from "@/lib/auth-utils"

// Create a new item
const itemSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  description: z.string().optional(),
  basePrice: z.coerce.number().min(0, "Price must be a positive number"),
  tourId: z.string().min(1, "Tour ID is required"),
  category: z.string().min(1, "Category is required"),
})

export async function createItem(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "TOUR_MANAGER"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    const validatedFields = itemSchema.parse({
      name: formData.get("name"),
      description: formData.get("description"),
      basePrice: formData.get("basePrice"),
      tourId: formData.get("tourId"),
      category: formData.get("category"),
    })

    const item = await prisma.item.create({
      data: validatedFields,
    })

    revalidatePath("/inventory")
    return { success: true, item }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}

// Create a new item variant
const variantSchema = z.object({
  itemId: z.string().min(1, "Item ID is required"),
  sku: z.string().min(1, "SKU is required"),
  size: z.string().optional(),
  color: z.string().optional(),
  price: z.coerce.number().optional(),
  costPrice: z.coerce.number().optional(),
})

export async function createItemVariant(formData: FormData) {
  try {
    const session = await auth()
    if (!session || !["ADMIN", "TOUR_MANAGER"].includes(session.user.role)) {
      return { error: "Unauthorized" }
    }

    const validatedFields = variantSchema.parse({
      itemId: formData.get("itemId"),
      sku: formData.get("sku"),
      size: formData.get("size"),
      color: formData.get("color"),
      price: formData.get("price"),
      costPrice: formData.get("costPrice"),
    })

    const variant = await prisma.itemVariant.create({
      data: validatedFields,
    })

    revalidatePath("/inventory")
    return { success: true, variant }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}

// Update show inventory
const inventoryUpdateSchema = z.object({
  showId: z.string().min(1, "Show ID is required"),
  variantId: z.string().min(1, "Variant ID is required"),
  initialStock: z.coerce.number().min(0, "Initial stock must be a positive number"),
  currentStock: z.coerce.number().min(0, "Current stock must be a positive number"),
  damagedCount: z.coerce.number().min(0, "Damaged count must be a positive number").optional(),
  lostCount: z.coerce.number().min(0, "Lost count must be a positive number").optional(),
  restockCount: z.coerce.number().min(0, "Restock count must be a positive number").optional(),
})

export async function updateShowInventory(formData: FormData) {
  try {
    const session = await auth()
    if (!session) {
      return { error: "Unauthorized" }
    }

    const validatedFields = inventoryUpdateSchema.parse({
      showId: formData.get("showId"),
      variantId: formData.get("variantId"),
      initialStock: formData.get("initialStock"),
      currentStock: formData.get("currentStock"),
      damagedCount: formData.get("damagedCount") || 0,
      lostCount: formData.get("lostCount") || 0,
      restockCount: formData.get("restockCount") || 0,
    })

    const { showId, variantId } = validatedFields

    // Check if inventory record exists
    const existingInventory = await prisma.showInventory.findFirst({
      where: {
        showId,
        variantId,
      },
    })

    let inventory
    if (existingInventory) {
      // Update existing record
      inventory = await prisma.showInventory.update({
        where: { id: existingInventory.id },
        data: validatedFields,
      })
    } else {
      // Create new record
      inventory = await prisma.showInventory.create({
        data: validatedFields,
      })
    }

    revalidatePath("/inventory")
    return { success: true, inventory }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message }
    }
    return { error: "Something went wrong. Please try again." }
  }
}
