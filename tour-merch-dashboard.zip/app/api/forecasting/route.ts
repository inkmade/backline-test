import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth-utils"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { tourId, showId } = body

    if (!tourId) {
      return NextResponse.json({ error: "Tour ID is required" }, { status: 400 })
    }

    // Get historical sales data
    const historicalSales = await prisma.sale.findMany({
      where: {
        show: {
          tourId,
        },
      },
      include: {
        items: {
          include: {
            variant: {
              include: {
                item: true,
              },
            },
          },
        },
        show: {
          include: {
            venue: true,
          },
        },
      },
      orderBy: {
        saleTime: "desc",
      },
    })

    // Get upcoming shows
    const upcomingShows = await prisma.show.findMany({
      where: {
        tourId,
        date: {
          gte: new Date(),
        },
      },
      include: {
        venue: true,
      },
      orderBy: {
        date: "asc",
      },
    })

    // Get current inventory
    const inventory = await prisma.showInventory.findMany({
      where: {
        show: {
          tourId,
        },
      },
      include: {
        variant: {
          include: {
            item: true,
          },
        },
        show: true,
      },
    })

    // Prepare data for AI analysis
    const salesData = historicalSales.map((sale) => ({
      date: sale.saleTime,
      venue: sale.show.venue.name,
      city: sale.show.venue.city,
      state: sale.show.venue.state,
      items: sale.items.map((item) => ({
        name: item.variant.item.name,
        variant: `${item.variant.size || ""} ${item.variant.color || ""}`.trim(),
        quantity: item.quantity,
        price: item.unitPrice,
      })),
    }))

    const inventoryData = inventory.map((inv) => ({
      item: inv.variant.item.name,
      variant: `${inv.variant.size || ""} ${inv.variant.color || ""}`.trim(),
      currentStock: inv.currentStock,
      soldCount: inv.soldCount,
    }))

    const upcomingShowsData = upcomingShows.map((show) => ({
      date: show.date,
      venue: show.venue.name,
      city: show.venue.city,
      state: show.venue.state,
      capacity: show.venue.capacity,
    }))

    // Generate AI forecast
    const prompt = `
      You are an AI merchandise sales forecasting assistant for a touring band or artist.
      
      Here is the historical sales data:
      ${JSON.stringify(salesData)}
      
      Here is the current inventory data:
      ${JSON.stringify(inventoryData)}
      
      Here are the upcoming shows:
      ${JSON.stringify(upcomingShowsData)}
      
      Based on this data, please provide:
      1. Sales forecast for each upcoming show (total units and revenue)
      2. Item-level sales predictions for each upcoming show
      3. Restock recommendations (which items need to be restocked and by when)
      4. Insights on sales trends and patterns
      
      Format your response as JSON with the following structure:
      {
        "forecasts": [
          {
            "showDate": "YYYY-MM-DD",
            "venue": "Venue Name",
            "predictedUnits": number,
            "predictedRevenue": number,
            "itemPredictions": [
              {
                "item": "Item Name",
                "variant": "Size Color",
                "predictedUnits": number
              }
            ]
          }
        ],
        "restockRecommendations": [
          {
            "item": "Item Name",
            "variant": "Size Color",
            "currentStock": number,
            "recommendedRestock": number,
            "priority": "High|Medium|Low",
            "restockBy": "YYYY-MM-DD"
          }
        ],
        "insights": [
          "Insight 1",
          "Insight 2"
        ]
      }
    `

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    // Parse the AI response
    const aiResponse = JSON.parse(text)

    return NextResponse.json(aiResponse)
  } catch (error) {
    console.error("Error generating forecast:", error)
    return NextResponse.json({ error: "Failed to generate forecast" }, { status: 500 })
  }
}
