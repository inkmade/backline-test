import { NextResponse } from "next/server"
import { auth } from "@/lib/auth-utils"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const showId = params.id

    // Get detailed inventory for the show
    const inventory = await prisma.showInventory.findMany({
      where: {
        showId,
      },
      include: {
        variant: {
          include: {
            item: true,
          },
        },
      },
    })

    // Format the inventory data
    const formattedInventory = inventory.map((inv) => ({
      id: inv.id,
      showId: inv.showId,
      item: inv.variant.item.name,
      itemId: inv.variant.item.id,
      category: inv.variant.item.category,
      size: inv.variant.size,
      color: inv.variant.color,
      sku: inv.variant.sku,
      variantId: inv.variantId,
      currentStock: inv.currentStock,
      initialStock: inv.initialStock,
      soldCount: inv.soldCount,
      damagedCount: inv.damagedCount || 0,
      lostCount: inv.lostCount || 0,
      restockCount: inv.restockCount || 0,
      stockPercentage: inv.initialStock > 0 ? Math.round((inv.currentStock / inv.initialStock) * 100) : 0,
      status:
        inv.currentStock === 0 ? "Out of Stock" : inv.currentStock < inv.initialStock * 0.2 ? "Low Stock" : "In Stock",
    }))

    return NextResponse.json(formattedInventory)
  } catch (error) {
    console.error("Error fetching inventory data:", error)
    return NextResponse.json({ error: "Failed to fetch inventory data" }, { status: 500 })
  }
}
