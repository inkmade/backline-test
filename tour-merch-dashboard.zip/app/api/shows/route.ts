import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth-utils"

export async function GET(request: NextRequest) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const tourId = searchParams.get("tourId")
    const upcoming = searchParams.get("upcoming") === "true"
    const past = searchParams.get("past") === "true"

    const query: any = {}

    if (tourId) {
      query.tourId = tourId
    }

    if (upcoming) {
      query.date = {
        gte: new Date(),
      }
    } else if (past) {
      query.date = {
        lt: new Date(),
      }
    }

    const shows = await prisma.show.findMany({
      where: query,
      include: {
        tour: true,
        venue: true,
        taxRate: true,
      },
      orderBy: {
        date: "asc",
      },
    })

    return NextResponse.json(shows)
  } catch (error) {
    console.error("Error fetching shows:", error)
    return NextResponse.json({ error: "Failed to fetch shows" }, { status: 500 })
  }
}
