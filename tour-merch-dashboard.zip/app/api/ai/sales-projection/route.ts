import { NextResponse } from "next/server"
import { auth } from "@/lib/auth-utils"
import { generateText } from "ai"
import { xai } from "@ai-sdk/xai"
import { isDemoMode } from "@/lib/mock-data-service"

export async function POST(request: Request) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()

    if (isDemoMode()) {
      // Return mock AI projection data for demo
      return NextResponse.json({
        projections: {
          categories: [
            {
              category: "T-Shirts",
              projectedUnits: 250,
              projectedRevenue: 6250.0,
              confidenceLevel: "High",
            },
            {
              category: "Hoodies",
              projectedUnits: 120,
              projectedRevenue: 6600.0,
              confidenceLevel: "Medium",
            },
            {
              category: "Posters",
              projectedUnits: 180,
              projectedRevenue: 3600.0,
              confidenceLevel: "High",
            },
            {
              category: "Accessories",
              projectedUnits: 150,
              projectedRevenue: 3000.0,
              confidenceLevel: "Medium",
            },
          ],
          items: [
            {
              item: "Tour Logo Tee",
              size: "M",
              projectedUnits: 85,
              projectedRevenue: 2125.0,
              confidenceLevel: "High",
            },
            {
              item: "Tour Logo Tee",
              size: "S",
              projectedUnits: 65,
              projectedRevenue: 1625.0,
              confidenceLevel: "High",
            },
            {
              item: "Tour Logo Tee",
              size: "L",
              projectedUnits: 70,
              projectedRevenue: 1750.0,
              confidenceLevel: "Medium",
            },
            {
              item: "Tour Hoodie",
              size: "L",
              projectedUnits: 45,
              projectedRevenue: 2475.0,
              confidenceLevel: "Medium",
            },
            {
              item: "Tour Hoodie",
              size: "M",
              projectedUnits: 40,
              projectedRevenue: 2200.0,
              confidenceLevel: "Medium",
            },
            {
              item: "Tour Poster",
              size: null,
              projectedUnits: 180,
              projectedRevenue: 3600.0,
              confidenceLevel: "High",
            },
            {
              item: "Tour Beanie",
              size: null,
              projectedUnits: 90,
              projectedRevenue: 1800.0,
              confidenceLevel: "Medium",
            },
          ],
          venues: [
            {
              venueType: "Arena",
              projectedUnitsPerShow: 120,
              projectedRevenuePerShow: 3600.0,
              topCategories: ["T-Shirts", "Hoodies"],
            },
            {
              venueType: "Stadium",
              projectedUnitsPerShow: 200,
              projectedRevenuePerShow: 5500.0,
              topCategories: ["T-Shirts", "Posters"],
            },
            {
              venueType: "Theater",
              projectedUnitsPerShow: 75,
              projectedRevenuePerShow: 2250.0,
              topCategories: ["T-Shirts", "Accessories"],
            },
            {
              venueType: "Club",
              projectedUnitsPerShow: 50,
              projectedRevenuePerShow: 1500.0,
              topCategories: ["T-Shirts", "Accessories"],
            },
          ],
        },
        restockRecommendations: [
          {
            item: "Tour Logo Tee",
            size: "S",
            currentStock: 5,
            recommendedRestock: 30,
            priority: "High",
            restockBy: "2025-05-20",
            reason: "Low stock with high projected demand",
          },
          {
            item: "Tour Hoodie",
            size: "L",
            currentStock: 0,
            recommendedRestock: 25,
            priority: "High",
            restockBy: "2025-05-18",
            reason: "Out of stock with consistent demand",
          },
          {
            item: "Tour Logo Tee",
            size: "M",
            currentStock: 25,
            recommendedRestock: 20,
            priority: "Medium",
            restockBy: "2025-05-25",
            reason: "Medium stock with steady demand",
          },
          {
            item: "Tour Beanie",
            size: null,
            currentStock: 20,
            recommendedRestock: 15,
            priority: "Low",
            restockBy: "2025-06-01",
            reason: "Adequate stock for near-term demand",
          },
        ],
        totalProjectedRevenue: 19450.0,
        insights: [
          "T-Shirts continue to be the best-selling category across all venues",
          "Medium-sized venues show higher per-capita merchandise spending",
          "Hoodies are trending upward as the tour progresses",
          "Size M and L items consistently sell better than other sizes",
          "Accessories perform better in smaller venues",
          "Posters have the highest profit margin among all merchandise categories",
        ],
        recommendations: [
          "Prioritize restocking small and medium T-shirts immediately",
          "Consider introducing a limited edition design for the final shows",
          "Adjust pricing strategy for accessories to improve margins",
          "Increase hoodie inventory for upcoming arena shows",
          "Create venue-specific merchandise bundles based on venue size",
          "Implement a pre-order system for high-demand items",
        ],
        sellerInsights: [
          {
            sellerId: "seller1",
            sellerName: "John Doe",
            insights: [
              "Consistently outperforms in T-shirt sales",
              "Has the highest average order value among all sellers",
              "Performs best at arena venues",
            ],
            recommendations: [
              "Could improve sales of accessories with bundling strategies",
              "Share successful T-shirt selling techniques with other team members",
              "Focus on upselling to increase average order value",
            ],
            projectedSales: 45,
            projectedRevenue: 2300.0,
            topCategories: ["T-Shirts", "Posters"],
          },
          {
            sellerId: "seller2",
            sellerName: "Jane Smith",
            insights: [
              "Excels at selling premium items like hoodies",
              "Has the highest conversion rate for upselling",
              "Performs consistently across all venue types",
            ],
            recommendations: [
              "Focus on selling more high-margin items",
              "Share upselling techniques with the team",
              "Could improve poster sales with targeted approach",
            ],
            projectedSales: 40,
            projectedRevenue: 2100.0,
            topCategories: ["Hoodies", "T-Shirts"],
          },
          {
            sellerId: "seller3",
            sellerName: "Alex Johnson",
            insights: [
              "Strongest performer with accessories",
              "Highest units sold per transaction",
              "Performs best at stadium venues",
            ],
            recommendations: [
              "Share accessory selling strategies with team",
              "Focus on increasing average order value",
              "Could improve hoodie sales with targeted approach",
            ],
            projectedSales: 48,
            projectedRevenue: 2450.0,
            topCategories: ["Accessories", "T-Shirts"],
          },
        ],
      })
    }

    // For production, use the real AI service
    const {
      remainingShows,
      totalTicketSales,
      averageAttendance,
      pastSalesData,
      currentInventory,
      inventoryAlerts,
      inventoryAggregates,
      venueTypes,
      tourDemographics,
      sellerPerformance,
    } = body

    // Prepare the prompt for Grok
    const prompt = `
      You are an expert AI assistant for tour merchandise managers. Your task is to analyze tour data and predict future merchandise sales to help with inventory planning.
      
      Here is the data about the remaining tour:
      - Remaining shows: ${remainingShows}
      - Total ticket sales for remaining shows: ${totalTicketSales}
      - Average attendance per show: ${averageAttendance}
      - Venue types: ${JSON.stringify(venueTypes)}
      - Tour demographics: ${JSON.stringify(tourDemographics)}
      
      Past sales data:
      ${JSON.stringify(pastSalesData.slice(0, 100))} ${pastSalesData.length > 100 ? `... and ${pastSalesData.length - 100} more records` : ""}
      
      Current inventory levels:
      ${JSON.stringify(currentInventory.slice(0, 50))} ${currentInventory.length > 50 ? `... and ${currentInventory.length - 50} more records` : ""}
      
      Inventory alerts (low stock or out of stock items):
      ${JSON.stringify(inventoryAlerts)}
      
      Inventory aggregates by category:
      ${JSON.stringify(inventoryAggregates)}
      
      Seller performance data:
      ${JSON.stringify(sellerPerformance)}
      
      Based on this information, please provide:
      1. Projected sales for each merchandise category for the remaining shows
      2. Specific restock recommendations (which items need to be restocked and by when)
      3. Expected revenue from merchandise for the remaining shows
      4. Insights on sales trends and patterns
      5. Recommendations for optimizing inventory and maximizing revenue
      6. Seller-specific insights and recommendations
      7. Venue-specific projections (how sales might differ by venue type)
      
      Format your response as JSON with the following structure:
      {
        "projections": {
          "categories": [
            {
              "category": "string",
              "projectedUnits": number,
              "projectedRevenue": number,
              "confidenceLevel": "High|Medium|Low"
            }
          ],
          "items": [
            {
              "item": "string",
              "size": "string",
              "projectedUnits": number,
              "projectedRevenue": number,
              "confidenceLevel": "High|Medium|Low"
            }
          ],
          "venues": [
            {
              "venueType": "string",
              "projectedUnitsPerShow": number,
              "projectedRevenuePerShow": number,
              "topCategories": ["string"]
            }
          ]
        },
        "restockRecommendations": [
          {
            "item": "string",
            "size": "string",
            "currentStock": number,
            "recommendedRestock": number,
            "priority": "High|Medium|Low",
            "restockBy": "YYYY-MM-DD",
            "reason": "string"
          }
        ],
        "totalProjectedRevenue": number,
        "insights": [
          "string"
        ],
        "recommendations": [
          "string"
        ],
        "sellerInsights": [
          {
            "sellerId": "string",
            "sellerName": "string",
            "insights": ["string"],
            "recommendations": ["string"],
            "projectedSales": number,
            "projectedRevenue": number,
            "topCategories": ["string"]
          }
        ]
      }
    `

    // Generate the projection using Grok
    const { text } = await generateText({
      model: xai("grok-1"),
      prompt,
      temperature: 0.2, // Lower temperature for more consistent, analytical responses
      maxTokens: 3000,
    })

    // Parse the response
    const projectionData = JSON.parse(text)

    return NextResponse.json(projectionData)
  } catch (error) {
    console.error("Error generating sales projection:", error)
    return NextResponse.json({ error: "Failed to generate sales projection" }, { status: 500 })
  }
}
