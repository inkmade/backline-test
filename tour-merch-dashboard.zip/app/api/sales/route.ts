import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth-utils"

export async function GET(request: NextRequest) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const showId = searchParams.get("showId")
    const tourId = searchParams.get("tourId")
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")

    const query: any = {}

    if (showId) {
      query.showId = showId
    } else if (tourId) {
      query.show = {
        tourId,
      }
    }

    if (startDate && endDate) {
      query.saleTime = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      }
    }

    const sales = await prisma.sale.findMany({
      where: query,
      include: {
        show: {
          include: {
            venue: true,
            tour: true,
          },
        },
        seller: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        items: {
          include: {
            variant: {
              include: {
                item: true,
              },
            },
          },
        },
      },
      orderBy: {
        saleTime: "desc",
      },
    })

    return NextResponse.json(sales)
  } catch (error) {
    console.error("Error fetching sales:", error)
    return NextResponse.json({ error: "Failed to fetch sales" }, { status: 500 })
  }
}
