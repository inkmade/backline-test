import { NextResponse } from "next/server"
import { hash } from "bcryptjs"
import { prisma } from "@/lib/prisma"
import { isDemoMode } from "@/lib/mock-data-service"

export async function POST(req: Request) {
  try {
    const { name, email, password } = await req.json()

    // Validate fields
    if (!name || !email || !password) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if user already exists
    if (isDemoMode()) {
      // In demo mode, always succeed but don't actually create a user
      if (email === "demo@example.com") {
        return NextResponse.json({ error: "User already exists" }, { status: 400 })
      }

      return NextResponse.json({ success: true, message: "User registered successfully" }, { status: 201 })
    }

    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      return NextResponse.json({ error: "User already exists" }, { status: 400 })
    }

    // Hash password
    const hashedPassword = await hash(password, 10)

    // Create user
    const user = await prisma.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        role: "USER", // Default role
      },
    })

    return NextResponse.json({ success: true, message: "User registered successfully" }, { status: 201 })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 })
  }
}
