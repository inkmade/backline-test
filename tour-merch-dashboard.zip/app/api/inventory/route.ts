import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth-utils"

export async function GET(request: NextRequest) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const showId = searchParams.get("showId")
    const tourId = searchParams.get("tourId")

    const query: any = {}

    if (showId) {
      // Get inventory for a specific show
      const inventory = await prisma.showInventory.findMany({
        where: {
          showId,
        },
        include: {
          variant: {
            include: {
              item: true,
            },
          },
        },
      })
      return NextResponse.json(inventory)
    } else if (tourId) {
      // Get all items for a tour
      const items = await prisma.item.findMany({
        where: {
          tourId,
        },
        include: {
          variants: true,
        },
      })
      return NextResponse.json(items)
    } else {
      // Get all items
      const items = await prisma.item.findMany({
        include: {
          variants: true,
          tour: true,
        },
      })
      return NextResponse.json(items)
    }
  } catch (error) {
    console.error("Error fetching inventory:", error)
    return NextResponse.json({ error: "Failed to fetch inventory" }, { status: 500 })
  }
}
