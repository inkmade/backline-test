import { NextResponse } from "next/server"
import { auth } from "@/lib/auth-utils"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const tourId = params.id

    // Get all sales for the tour
    const sales = await prisma.sale.findMany({
      where: {
        show: {
          tourId,
        },
      },
      include: {
        seller: true,
        items: {
          include: {
            variant: {
              include: {
                item: true,
              },
            },
          },
        },
        show: true,
      },
    })

    // Group sales by seller
    const sellerMap = new Map()

    sales.forEach((sale) => {
      const sellerId = sale.sellerId

      if (!sellerMap.has(sellerId)) {
        sellerMap.set(sellerId, {
          id: sellerId,
          name: sale.seller.name,
          role: sale.seller.role,
          totalSales: 0,
          totalRevenue: 0,
          itemsSold: 0,
          averageOrderValue: 0,
          salesByCategory: {},
          salesByShow: {},
          topSellingItems: [],
        })
      }

      const sellerData = sellerMap.get(sellerId)
      sellerData.totalSales += 1
      sellerData.totalRevenue += sale.total

      // Track items sold
      const itemCount = sale.items.reduce((sum, item) => sum + item.quantity, 0)
      sellerData.itemsSold += itemCount

      // Track sales by category
      sale.items.forEach((item) => {
        const category = item.variant.item.category
        if (!sellerData.salesByCategory[category]) {
          sellerData.salesByCategory[category] = {
            quantity: 0,
            revenue: 0,
          }
        }
        sellerData.salesByCategory[category].quantity += item.quantity
        sellerData.salesByCategory[category].revenue += item.totalPrice

        // Track top selling items
        const itemKey = `${item.variant.item.name}-${item.variant.size || "N/A"}`
        const existingItem = sellerData.topSellingItems.find((i) => i.key === itemKey)

        if (existingItem) {
          existingItem.quantity += item.quantity
          existingItem.revenue += item.totalPrice
        } else {
          sellerData.topSellingItems.push({
            key: itemKey,
            name: item.variant.item.name,
            size: item.variant.size,
            quantity: item.quantity,
            revenue: item.totalPrice,
          })
        }
      })

      // Track sales by show
      const showId = sale.showId
      if (!sellerData.salesByShow[showId]) {
        sellerData.salesByShow[showId] = {
          showName: sale.show.name,
          date: sale.show.date,
          salesCount: 0,
          revenue: 0,
        }
      }
      sellerData.salesByShow[showId].salesCount += 1
      sellerData.salesByShow[showId].revenue += sale.total
    })

    // Calculate averages and sort top selling items
    const sellerPerformance = Array.from(sellerMap.values()).map((seller) => {
      seller.averageOrderValue = seller.totalSales > 0 ? seller.totalRevenue / seller.totalSales : 0
      seller.topSellingItems.sort((a, b) => b.quantity - a.quantity)
      seller.topSellingItems = seller.topSellingItems.slice(0, 5) // Keep only top 5
      return seller
    })

    return NextResponse.json(sellerPerformance)
  } catch (error) {
    console.error("Error fetching seller performance data:", error)
    return NextResponse.json({ error: "Failed to fetch seller performance data" }, { status: 500 })
  }
}
