import { NextResponse } from "next/server"
import { auth } from "@/lib/auth-utils"
import { dataService } from "@/lib/mock-data-service"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const tourId = params.id
    const projectionData = await dataService.getProjectionData(tourId)

    return NextResponse.json(projectionData)
  } catch (error) {
    console.error("Error fetching projection data:", error)
    return NextResponse.json({ error: "Failed to fetch projection data" }, { status: 500 })
  }
}
