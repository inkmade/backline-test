import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth-utils"

export async function GET(request: NextRequest) {
  try {
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const upcoming = searchParams.get("upcoming") === "true"
    const past = searchParams.get("past") === "true"

    const query: any = {}

    // If user is not an admin, only show tours they manage
    if (session.user.role !== "ADMIN") {
      query.managers = {
        some: {
          id: session.user.id,
        },
      }
    }

    if (upcoming) {
      query.endDate = {
        gte: new Date(),
      }
    } else if (past) {
      query.endDate = {
        lt: new Date(),
      }
    }

    const tours = await prisma.tour.findMany({
      where: query,
      include: {
        shows: {
          include: {
            venue: true,
          },
          orderBy: {
            date: "asc",
          },
        },
        managers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: {
        startDate: "asc",
      },
    })

    return NextResponse.json(tours)
  } catch (error) {
    console.error("Error fetching tours:", error)
    return NextResponse.json({ error: "Failed to fetch tours" }, { status: 500 })
  }
}
