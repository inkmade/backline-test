import { Suspense } from "react"
import { auth } from "@/lib/auth-utils"
import { redirect } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { AISalesProjection } from "@/components/ai-sales-projection"
import { Skeleton } from "@/components/ui/skeleton"

export default async function AiProjectionPage({
  searchParams,
}: {
  searchParams: { tourId?: string }
}) {
  const session = await auth()

  if (!session) {
    redirect("/login")
  }

  const tourId = searchParams.tourId

  return (
    <DashboardLayout>
      <Suspense fallback={<ProjectionSkeleton />}>
        <AISalesProjection tourId={tourId} />
      </Suspense>
    </DashboardLayout>
  )
}

function ProjectionSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <Skeleton className="h-8 w-64" />
          <Skeleton className="mt-2 h-4 w-40" />
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className="h-10 w-[200px]" />
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-10 w-40" />
        </div>
      </div>

      <Skeleton className="h-[400px]" />
    </div>
  )
}
