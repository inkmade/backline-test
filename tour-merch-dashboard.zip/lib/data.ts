import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function getDashboardData() {
  try {
    // Get total revenue
    const totalRevenueResult = await sql`
      SELECT SUM(total) as total_revenue
      FROM "Sale"
      WHERE "paymentStatus" = 'COMPLETED'
    `
    const totalRevenue = totalRevenueResult[0]?.total_revenue || 0

    // Get total sales count
    const totalSalesResult = await sql`
      SELECT COUNT(*) as total_sales
      FROM "Sale"
      WHERE "paymentStatus" = 'COMPLETED'
    `
    const totalSales = totalSalesResult[0]?.total_sales || 0

    // Get active tours
    const activeToursResult = await sql`
      SELECT COUNT(*) as active_tours
      FROM "Tour"
      WHERE "endDate" >= CURRENT_DATE
    `
    const activeTours = activeToursResult[0]?.active_tours || 0

    // Get upcoming shows
    const upcomingShowsResult = await sql`
      SELECT COUNT(*) as upcoming_shows
      FROM "Show"
      WHERE "date" >= CURRENT_DATE
    `
    const upcomingShows = upcomingShowsResult[0]?.upcoming_shows || 0

    // Get inventory value
    const inventoryValueResult = await sql`
      SELECT SUM(iv."currentStock" * v."price") as inventory_value
      FROM "ShowInventory" iv
      JOIN "ItemVariant" v ON iv."variantId" = v.id
    `
    const inventoryValue = inventoryValueResult[0]?.inventory_value || 0

    // Get low stock items
    const lowStockItemsResult = await sql`
      SELECT COUNT(*) as low_stock_items
      FROM "ShowInventory"
      WHERE "currentStock" < 10
    `
    const lowStockItems = lowStockItemsResult[0]?.low_stock_items || 0

    // Get recent sales
    const recentSales = await sql`
      SELECT s.id, u.name as seller_name, s."saleTime", s.total, s."paymentMethod"
      FROM "Sale" s
      JOIN "User" u ON s."sellerId" = u.id
      ORDER BY s."saleTime" DESC
      LIMIT 5
    `

    // Get top selling items
    const topSellingItems = await sql`
      SELECT i.name, i.category, SUM(si.quantity) as total_sold, SUM(si."totalPrice") as revenue
      FROM "SaleItem" si
      JOIN "ItemVariant" iv ON si."variantId" = iv.id
      JOIN "Item" i ON iv."itemId" = i.id
      GROUP BY i.name, i.category
      ORDER BY total_sold DESC
      LIMIT 5
    `

    // Get tour schedule
    const tourSchedule = await sql`
      SELECT s.id, s.date, v.name as venue, v.city, v.state, v.capacity
      FROM "Show" s
      JOIN "Venue" v ON s."venueId" = v.id
      WHERE s.date >= CURRENT_DATE
      ORDER BY s.date
      LIMIT 5
    `

    // Format the data for the frontend
    const formattedRecentSales = recentSales.map((sale) => ({
      id: sale.id,
      name: sale.seller_name,
      email: "customer@example.com", // Placeholder
      amount: `+$${sale.total.toFixed(2)}`,
      date: new Date(sale.saleTime).toISOString().split("T")[0],
      status: "success",
      items: ["Item 1", "Item 2"], // Placeholder
    }))

    const formattedTopSellingItems = topSellingItems.map((item) => ({
      id: Math.random().toString(36).substring(7),
      name: item.name,
      category: item.category,
      sold: item.total_sold,
      revenue: `$${item.revenue.toFixed(2)}`,
      profit: `$${(item.revenue * 0.6).toFixed(2)}`, // Placeholder profit calculation
    }))

    const formattedTourSchedule = tourSchedule.map((show) => ({
      id: show.id,
      date: new Date(show.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }),
      venue: show.venue,
      location: `${show.city}, ${show.state}`,
      status: "upcoming",
      ticketsSold: `${Math.floor(Math.random() * show.capacity)} / ${show.capacity}`,
      soldOut: Math.random() > 0.8,
    }))

    // Monthly revenue data for the overview chart
    const overviewData = [
      { name: "Jan", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Feb", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Mar", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Apr", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "May", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Jun", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Jul", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Aug", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Sep", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Oct", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Nov", total: Math.floor(Math.random() * 5000) + 1000 },
      { name: "Dec", total: Math.floor(Math.random() * 5000) + 1000 },
    ]

    return {
      totalRevenue,
      revenueIncrease: 20.1, // Placeholder
      totalSales,
      salesIncrease: 15.2, // Placeholder
      activeTours,
      upcomingShows,
      inventoryValue,
      lowStockItems,
      recentSales: formattedRecentSales,
      recentSalesCount: formattedRecentSales.length,
      topSellingItems: formattedTopSellingItems,
      tourSchedule: formattedTourSchedule,
      overviewData,
    }
  } catch (error) {
    console.error("Error fetching dashboard data:", error)
    return {
      error: "Failed to fetch dashboard data",
    }
  }
}
