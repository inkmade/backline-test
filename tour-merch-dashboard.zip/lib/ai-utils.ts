import { prisma } from "@/lib/prisma"

export async function getSalesProjectionData(tourId: string) {
  try {
    // Get tour information
    const tour = await prisma.tour.findUnique({
      where: { id: tourId },
      include: {
        shows: {
          include: {
            venue: true,
            sales: {
              include: {
                seller: true, // Include the seller (user) information
                items: {
                  include: {
                    variant: {
                      include: {
                        item: true,
                      },
                    },
                  },
                },
              },
            },
            inventory: {
              // Include detailed inventory for each show
              include: {
                variant: {
                  include: {
                    item: true,
                  },
                },
              },
            },
          },
        },
      },
    })

    if (!tour) {
      throw new Error("Tour not found")
    }

    // Calculate remaining shows
    const currentDate = new Date()
    const remainingShows = tour.shows.filter((show) => new Date(show.date) > currentDate)
    const pastShows = tour.shows.filter((show) => new Date(show.date) <= currentDate)

    // Calculate total ticket sales and average attendance
    const totalTicketSales = remainingShows.reduce((sum, show) => sum + show.venue.capacity, 0)
    const averageAttendance =
      pastShows.length > 0 ? pastShows.reduce((sum, show) => sum + show.venue.capacity * 0.85, 0) / pastShows.length : 0

    // Get venue types
    const venueTypes = Array.from(
      new Set(
        remainingShows.map((show) => {
          const capacity = show.venue.capacity
          if (capacity < 1000) return "Small"
          if (capacity < 3000) return "Medium"
          return "Large"
        }),
      ),
    )

    // Get past sales data with seller information
    const pastSalesData = pastShows.flatMap((show) => {
      return show.sales.flatMap((sale) => {
        return sale.items.map((item) => ({
          date: sale.saleTime,
          venue: show.venue.name,
          venueCapacity: show.venue.capacity,
          item: item.variant.item.name,
          category: item.variant.item.category,
          size: item.variant.size,
          quantity: item.quantity,
          revenue: item.totalPrice,
          sellerId: sale.sellerId,
          sellerName: sale.seller.name,
          sellerRole: sale.seller.role,
        }))
      })
    })

    // Get detailed current inventory across all remaining shows
    const currentInventory = remainingShows.flatMap((show) =>
      show.inventory.map((inv) => ({
        showId: show.id,
        showName: show.name,
        showDate: show.date,
        venue: show.venue.name,
        item: inv.variant.item.name,
        itemId: inv.variant.item.id,
        category: inv.variant.item.category,
        size: inv.variant.size,
        color: inv.variant.color,
        sku: inv.variant.sku,
        variantId: inv.variantId,
        currentStock: inv.currentStock,
        initialStock: inv.initialStock,
        soldCount: inv.soldCount,
        damagedCount: inv.damagedCount || 0,
        lostCount: inv.lostCount || 0,
        restockCount: inv.restockCount || 0,
      })),
    )

    // Get inventory alerts (low stock, out of stock, etc.)
    const inventoryAlerts = currentInventory
      .filter((inv) => {
        // Items with less than 20% of initial stock remaining
        const lowStockThreshold = inv.initialStock * 0.2
        return inv.currentStock <= lowStockThreshold
      })
      .map((inv) => ({
        ...inv,
        alertType: inv.currentStock === 0 ? "Out of Stock" : "Low Stock",
        stockPercentage: Math.round((inv.currentStock / inv.initialStock) * 100),
      }))

    // Get seller performance data
    const sellerPerformance = await getSellerPerformanceData(tourId)

    // Estimate tour demographics based on past sales
    const tourDemographics = {
      ageGroups: ["18-24", "25-34", "35-44", "45+"],
      genderSplit: { male: "55%", female: "45%" },
      topSellingItems: getTopSellingItems(pastSalesData, 5),
    }

    // Calculate inventory aggregates
    const inventoryAggregates = calculateInventoryAggregates(currentInventory)

    return {
      remainingShows: remainingShows.length,
      totalTicketSales,
      averageAttendance,
      pastSalesData,
      currentInventory,
      inventoryAlerts,
      inventoryAggregates,
      venueTypes,
      tourDemographics,
      sellerPerformance,
    }
  } catch (error) {
    console.error("Error fetching sales projection data:", error)
    throw error
  }
}

// Get seller performance data
async function getSellerPerformanceData(tourId: string) {
  const sales = await prisma.sale.findMany({
    where: {
      show: {
        tourId,
      },
    },
    include: {
      seller: true,
      items: {
        include: {
          variant: {
            include: {
              item: true,
            },
          },
        },
      },
      show: true,
    },
  })

  // Group sales by seller
  const sellerMap = new Map()

  sales.forEach((sale) => {
    const sellerId = sale.sellerId

    if (!sellerMap.has(sellerId)) {
      sellerMap.set(sellerId, {
        id: sellerId,
        name: sale.seller.name,
        role: sale.seller.role,
        totalSales: 0,
        totalRevenue: 0,
        itemsSold: 0,
        averageOrderValue: 0,
        salesByCategory: {},
        salesByShow: {},
        topSellingItems: [],
      })
    }

    const sellerData = sellerMap.get(sellerId)
    sellerData.totalSales += 1
    sellerData.totalRevenue += sale.total

    // Track items sold
    const itemCount = sale.items.reduce((sum, item) => sum + item.quantity, 0)
    sellerData.itemsSold += itemCount

    // Track sales by category
    sale.items.forEach((item) => {
      const category = item.variant.item.category
      if (!sellerData.salesByCategory[category]) {
        sellerData.salesByCategory[category] = {
          quantity: 0,
          revenue: 0,
        }
      }
      sellerData.salesByCategory[category].quantity += item.quantity
      sellerData.salesByCategory[category].revenue += item.totalPrice

      // Track top selling items
      const itemKey = `${item.variant.item.name}-${item.variant.size || "N/A"}`
      const existingItem = sellerData.topSellingItems.find((i) => i.key === itemKey)

      if (existingItem) {
        existingItem.quantity += item.quantity
        existingItem.revenue += item.totalPrice
      } else {
        sellerData.topSellingItems.push({
          key: itemKey,
          name: item.variant.item.name,
          size: item.variant.size,
          quantity: item.quantity,
          revenue: item.totalPrice,
        })
      }
    })

    // Track sales by show
    const showId = sale.showId
    if (!sellerData.salesByShow[showId]) {
      sellerData.salesByShow[showId] = {
        showName: sale.show.name,
        date: sale.show.date,
        salesCount: 0,
        revenue: 0,
      }
    }
    sellerData.salesByShow[showId].salesCount += 1
    sellerData.salesByShow[showId].revenue += sale.total
  })

  // Calculate averages and sort top selling items
  const sellerPerformance = Array.from(sellerMap.values()).map((seller) => {
    seller.averageOrderValue = seller.totalSales > 0 ? seller.totalRevenue / seller.totalSales : 0
    seller.topSellingItems.sort((a, b) => b.quantity - a.quantity)
    seller.topSellingItems = seller.topSellingItems.slice(0, 5) // Keep only top 5
    return seller
  })

  return sellerPerformance
}

// Calculate inventory aggregates
function calculateInventoryAggregates(inventory) {
  // Group by category
  const categoryMap = new Map()

  inventory.forEach((item) => {
    const category = item.category

    if (!categoryMap.has(category)) {
      categoryMap.set(category, {
        category,
        totalItems: 0,
        totalCurrentStock: 0,
        totalInitialStock: 0,
        totalSold: 0,
        totalDamaged: 0,
        totalLost: 0,
        stockPercentage: 0,
      })
    }

    const categoryData = categoryMap.get(category)
    categoryData.totalItems += 1
    categoryData.totalCurrentStock += item.currentStock
    categoryData.totalInitialStock += item.initialStock
    categoryData.totalSold += item.soldCount
    categoryData.totalDamaged += item.damagedCount
    categoryData.totalLost += item.lostCount
  })

  // Calculate percentages and convert to array
  return Array.from(categoryMap.values()).map((category) => {
    category.stockPercentage =
      category.totalInitialStock > 0 ? Math.round((category.totalCurrentStock / category.totalInitialStock) * 100) : 0
    return category
  })
}

function getTopSellingItems(salesData, count = 5) {
  // Group sales by item and calculate total quantity
  const itemSales = salesData.reduce((acc, sale) => {
    const key = `${sale.item}${sale.size ? ` (${sale.size})` : ""}`
    if (!acc[key]) {
      acc[key] = { item: key, quantity: 0, revenue: 0 }
    }
    acc[key].quantity += sale.quantity
    acc[key].revenue += sale.revenue
    return acc
  }, {})

  // Convert to array and sort by quantity
  return Object.values(itemSales)
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, count)
}
