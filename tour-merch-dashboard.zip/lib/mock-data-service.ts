import { neon } from "@neondatabase/serverless"

// Create a SQL client that uses the connection string from environment variables
export const sql = neon(process.env.DATABASE_URL || "postgresql://user:pass@localhost:5432/db")

// Helper function to execute SQL queries
export async function executeQuery(query: string, params: any[] = []) {
  try {
    return await sql(query, params)
  } catch (error) {
    console.error("Database query error:", error)
    // Return empty array if query fails
    return []
  }
}

// Flag to force demo mode
export const FORCE_DEMO_MODE = true

// Check if we're in demo mode
export const isDemoMode = () => {
  return (
    FORCE_DEMO_MODE ||
    process.env.DEMO_MODE === "true" ||
    process.env.VERCEL_ENV === "preview" ||
    !process.env.DATABASE_URL
  )
}

// Mock service to replace Prisma calls in demo mode
export const dataService = {
  // Authentication
  async getUser(email: string) {
    if (isDemoMode()) {
      if (email === "demo@example.com") {
        return {
          id: "user1",
          name: "Demo User",
          email: "demo@example.com",
          // This is a mock hash for 'password123'
          password: "$2a$10$8DnUwbvDKM7hXZOUmKO2c.xKLyBcGBDqPLE9hEKxD5tm7o9JOcQZi",
          role: "ADMIN",
        }
      }
      return null
    }

    try {
      const users = await executeQuery(`SELECT * FROM "User" WHERE email = $1`, [email])
      return users[0] || null
    } catch (error) {
      console.error("Error fetching user:", error)
      return null
    }
  },

  // Tour related queries
  async getTours() {
    if (isDemoMode()) {
      return mockTours
    }

    try {
      return await executeQuery(`SELECT * FROM "Tour" ORDER BY "startDate" DESC`)
    } catch (error) {
      console.error("Error fetching tours:", error)
      return mockTours
    }
  },

  async getUpcomingTours() {
    if (isDemoMode()) {
      return mockTours.filter((tour) => new Date(tour.endDate) > new Date())
    }

    try {
      return await executeQuery(`SELECT * FROM "Tour" WHERE "endDate" > NOW() ORDER BY "startDate" ASC`)
    } catch (error) {
      console.error("Error fetching upcoming tours:", error)
      return mockTours.filter((tour) => new Date(tour.endDate) > new Date())
    }
  },

  async getTour(tourId: string) {
    if (isDemoMode()) {
      const tour = mockTours.find((t) => t.id === tourId) || mockTours[0]
      return {
        ...tour,
        shows: mockShows.filter((s) => s.tourId === tourId),
      }
    }

    try {
      const tour = await executeQuery(`SELECT * FROM "Tour" WHERE id = $1`, [tourId])

      if (!tour || tour.length === 0) {
        return null
      }

      // Get shows for this tour
      const shows = await executeQuery(
        `SELECT s.*, v.name as venue_name, v.capacity as venue_capacity 
         FROM "Show" s 
         JOIN "Venue" v ON s.venueId = v.id 
         WHERE s.tourId = $1`,
        [tourId],
      )

      return {
        ...tour[0],
        shows: shows || [],
      }
    } catch (error) {
      console.error("Error fetching tour:", error)
      const tour = mockTours.find((t) => t.id === tourId) || mockTours[0]
      return {
        ...tour,
        shows: mockShows.filter((s) => s.tourId === tourId),
      }
    }
  },

  // Inventory related queries
  async getInventory(showId: string) {
    if (isDemoMode()) {
      return mockInventory.filter((i) => i.showId === showId)
    }

    try {
      const inventory = await executeQuery(
        `SELECT si.*, iv.size, iv.color, iv.sku, i.name as item_name, i.category 
         FROM "ShowInventory" si
         JOIN "ItemVariant" iv ON si.variantId = iv.id
         JOIN "Item" i ON iv.itemId = i.id
         WHERE si.showId = $1`,
        [showId],
      )

      if (!inventory || inventory.length === 0) {
        return mockInventory.filter((i) => i.showId === showId)
      }

      return inventory.map((inv) => ({
        id: inv.id,
        showId: inv.showId,
        item: inv.item_name,
        category: inv.category,
        size: inv.size,
        color: inv.color,
        sku: inv.sku,
        variantId: inv.variantId,
        currentStock: inv.currentStock,
        initialStock: inv.initialStock,
        soldCount: inv.soldCount,
        damagedCount: inv.damagedCount || 0,
        lostCount: inv.lostCount || 0,
        restockCount: inv.restockCount || 0,
        stockPercentage: inv.initialStock > 0 ? Math.round((inv.currentStock / inv.initialStock) * 100) : 0,
        status:
          inv.currentStock === 0
            ? "Out of Stock"
            : inv.currentStock < inv.initialStock * 0.2
              ? "Low Stock"
              : "In Stock",
      }))
    } catch (error) {
      console.error("Error fetching inventory:", error)
      return mockInventory.filter((i) => i.showId === showId)
    }
  },

  // Sales related queries
  async getSellerPerformance(tourId: string) {
    if (isDemoMode()) {
      return mockSellerPerformance
    }

    try {
      // This is a complex query that would join multiple tables
      // For demo purposes, we'll return mock data
      return mockSellerPerformance
    } catch (error) {
      console.error("Error fetching seller performance:", error)
      return mockSellerPerformance
    }
  },

  // Projection data
  async getProjectionData(tourId: string) {
    if (isDemoMode()) {
      return {
        remainingShows: 5,
        totalTicketSales: 7500,
        averageAttendance: 1200,
        pastSalesData: mockSalesData,
        currentInventory: mockInventoryItems,
        inventoryAlerts: mockInventoryAlerts,
        inventoryAggregates: mockInventoryAggregates,
        venueTypes: ["Arena", "Stadium", "Theater", "Club"],
        tourDemographics: mockTourDemographics,
        sellerPerformance: mockSellerPerformance,
      }
    }

    // In a real implementation, this would fetch data from the database
    // For now, return mock data
    return {
      remainingShows: 5,
      totalTicketSales: 7500,
      averageAttendance: 1200,
      pastSalesData: mockSalesData,
      currentInventory: mockInventoryItems,
      inventoryAlerts: mockInventoryAlerts,
      inventoryAggregates: mockInventoryAggregates,
      venueTypes: ["Arena", "Stadium", "Theater", "Club"],
      tourDemographics: mockTourDemographics,
      sellerPerformance: mockSellerPerformance,
    }
  },
}

// Mock data for fallback
const mockTours = [
  {
    id: "tour1",
    name: "Summer Tour 2025",
    startDate: "2025-06-01T00:00:00.000Z",
    endDate: "2025-08-31T00:00:00.000Z",
    description: "Summer tour across major cities",
    status: "UPCOMING",
    artist: "The Headliners",
    totalShows: 15,
    completedShows: 0,
  },
  {
    id: "tour2",
    name: "Winter Tour 2024",
    startDate: "2024-11-15T00:00:00.000Z",
    endDate: "2025-02-28T00:00:00.000Z",
    description: "Winter tour in indoor venues",
    status: "ACTIVE",
    artist: "The Headliners",
    totalShows: 20,
    completedShows: 5,
  },
  {
    id: "tour3",
    name: "Spring Tour 2024",
    startDate: "2024-03-01T00:00:00.000Z",
    endDate: "2024-05-30T00:00:00.000Z",
    description: "Spring tour in medium venues",
    status: "COMPLETED",
    artist: "The Headliners",
    totalShows: 12,
    completedShows: 12,
  },
]

const mockShows = [
  {
    id: "show1",
    tourId: "tour1",
    venueId: "venue1",
    venue_name: "Madison Square Garden",
    venue_capacity: 20000,
    date: "2025-06-15T19:00:00.000Z",
    loadInTime: "2025-06-15T10:00:00.000Z",
    doorsTime: "2025-06-15T17:00:00.000Z",
    showTime: "2025-06-15T19:00:00.000Z",
    city: "New York",
    state: "NY",
    country: "USA",
    ticketsSold: 18500,
    status: "SCHEDULED",
  },
  {
    id: "show2",
    tourId: "tour1",
    venueId: "venue2",
    venue_name: "The Forum",
    venue_capacity: 17500,
    date: "2025-06-22T19:00:00.000Z",
    loadInTime: "2025-06-22T10:00:00.000Z",
    doorsTime: "2025-06-22T17:00:00.000Z",
    showTime: "2025-06-22T19:00:00.000Z",
    city: "Los Angeles",
    state: "CA",
    country: "USA",
    ticketsSold: 16000,
    status: "SCHEDULED",
  },
  {
    id: "show3",
    tourId: "tour1",
    venueId: "venue3",
    venue_name: "United Center",
    venue_capacity: 23500,
    date: "2025-07-05T19:00:00.000Z",
    loadInTime: "2025-07-05T10:00:00.000Z",
    doorsTime: "2025-07-05T17:00:00.000Z",
    showTime: "2025-07-05T19:00:00.000Z",
    city: "Chicago",
    state: "IL",
    country: "USA",
    ticketsSold: 21000,
    status: "SCHEDULED",
  },
  {
    id: "show4",
    tourId: "tour2",
    venueId: "venue4",
    venue_name: "TD Garden",
    venue_capacity: 19580,
    date: "2024-12-10T19:00:00.000Z",
    loadInTime: "2024-12-10T10:00:00.000Z",
    doorsTime: "2024-12-10T17:00:00.000Z",
    showTime: "2024-12-10T19:00:00.000Z",
    city: "Boston",
    state: "MA",
    country: "USA",
    ticketsSold: 18000,
    status: "SCHEDULED",
  },
  {
    id: "show5",
    tourId: "tour2",
    venueId: "venue5",
    venue_name: "Scotiabank Arena",
    venue_capacity: 19800,
    date: "2024-12-15T19:00:00.000Z",
    loadInTime: "2024-12-15T10:00:00.000Z",
    doorsTime: "2024-12-15T17:00:00.000Z",
    showTime: "2024-12-15T19:00:00.000Z",
    city: "Toronto",
    state: "ON",
    country: "Canada",
    ticketsSold: 19000,
    status: "SCHEDULED",
  },
]

const mockInventory = [
  {
    id: "inv1",
    showId: "show1",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "S",
    color: "Black",
    sku: "TLT-S-BLK",
    variantId: "var1",
    currentStock: 5,
    initialStock: 50,
    soldCount: 45,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
    stockPercentage: 10,
    status: "Low Stock",
  },
  {
    id: "inv2",
    showId: "show1",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "M",
    color: "Black",
    sku: "TLT-M-BLK",
    variantId: "var2",
    currentStock: 25,
    initialStock: 50,
    soldCount: 25,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
    stockPercentage: 50,
    status: "In Stock",
  },
  {
    id: "inv3",
    showId: "show1",
    item: "Tour Hoodie",
    category: "Hoodies",
    size: "L",
    color: "Gray",
    sku: "TH-L-GRY",
    variantId: "var3",
    currentStock: 0,
    initialStock: 30,
    soldCount: 30,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
    stockPercentage: 0,
    status: "Out of Stock",
  },
  {
    id: "inv4",
    showId: "show2",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "S",
    color: "Black",
    sku: "TLT-S-BLK",
    variantId: "var1",
    currentStock: 10,
    initialStock: 50,
    soldCount: 40,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
    stockPercentage: 20,
    status: "Low Stock",
  },
  {
    id: "inv5",
    showId: "show2",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "M",
    color: "Black",
    sku: "TLT-M-BLK",
    variantId: "var2",
    currentStock: 15,
    initialStock: 50,
    soldCount: 35,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
    stockPercentage: 30,
    status: "In Stock",
  },
  {
    id: "inv6",
    showId: "show2",
    item: "Tour Poster",
    category: "Posters",
    size: "Standard",
    color: "Full Color",
    sku: "TP-STD-FC",
    variantId: "var4",
    currentStock: 25,
    initialStock: 100,
    soldCount: 75,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
    stockPercentage: 25,
    status: "In Stock",
  },
]

const mockSellerPerformance = [
  {
    id: "seller1",
    name: "John Doe",
    role: "SELLER",
    totalSales: 42,
    totalRevenue: 2150.75,
    itemsSold: 87,
    averageOrderValue: 51.21,
    salesByCategory: {
      "T-Shirts": { quantity: 35, revenue: 875.0 },
      Posters: { quantity: 22, revenue: 440.0 },
      Accessories: { quantity: 30, revenue: 835.75 },
    },
    topSellingItems: [
      { key: "Tour Logo Tee-M", name: "Tour Logo Tee", size: "M", quantity: 18, revenue: 450.0 },
      { key: "Tour Poster-N/A", name: "Tour Poster", size: null, quantity: 22, revenue: 440.0 },
    ],
  },
  {
    id: "seller2",
    name: "Jane Smith",
    role: "SELLER",
    totalSales: 38,
    totalRevenue: 1950.25,
    itemsSold: 76,
    averageOrderValue: 51.32,
    salesByCategory: {
      "T-Shirts": { quantity: 30, revenue: 750.0 },
      Hoodies: { quantity: 15, revenue: 825.0 },
      Accessories: { quantity: 31, revenue: 375.25 },
    },
    topSellingItems: [
      { key: "Tour Hoodie-L", name: "Tour Hoodie", size: "L", quantity: 10, revenue: 550.0 },
      { key: "Tour Logo Tee-S", name: "Tour Logo Tee", size: "S", quantity: 15, revenue: 375.0 },
    ],
  },
  {
    id: "seller3",
    name: "Alex Johnson",
    role: "SELLER",
    totalSales: 45,
    totalRevenue: 2350.5,
    itemsSold: 92,
    averageOrderValue: 52.23,
    salesByCategory: {
      "T-Shirts": { quantity: 40, revenue: 1000.0 },
      Hoodies: { quantity: 12, revenue: 660.0 },
      Accessories: { quantity: 40, revenue: 690.5 },
    },
    topSellingItems: [
      { key: "Tour Logo Tee-L", name: "Tour Logo Tee", size: "L", quantity: 22, revenue: 550.0 },
      { key: "Tour Beanie-N/A", name: "Tour Beanie", size: null, quantity: 18, revenue: 360.0 },
    ],
  },
]

const mockSalesData = [
  {
    id: "sale1",
    date: "2024-06-15T20:15:00.000Z",
    venue: "Madison Square Garden",
    venueCapacity: 20000,
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "M",
    quantity: 3,
    revenue: 75.0,
    sellerId: "seller1",
    sellerName: "John Doe",
    sellerRole: "SELLER",
  },
  {
    id: "sale2",
    date: "2024-06-15T20:30:00.000Z",
    venue: "Madison Square Garden",
    venueCapacity: 20000,
    item: "Tour Hoodie",
    category: "Hoodies",
    size: "L",
    quantity: 1,
    revenue: 55.0,
    sellerId: "seller2",
    sellerName: "Jane Smith",
    sellerRole: "SELLER",
  },
  {
    id: "sale3",
    date: "2024-06-15T21:00:00.000Z",
    venue: "Madison Square Garden",
    venueCapacity: 20000,
    item: "Tour Poster",
    category: "Posters",
    size: null,
    quantity: 2,
    revenue: 40.0,
    sellerId: "seller1",
    sellerName: "John Doe",
    sellerRole: "SELLER",
  },
  {
    id: "sale4",
    date: "2024-06-22T19:45:00.000Z",
    venue: "The Forum",
    venueCapacity: 17500,
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "S",
    quantity: 2,
    revenue: 50.0,
    sellerId: "seller2",
    sellerName: "Jane Smith",
    sellerRole: "SELLER",
  },
  {
    id: "sale5",
    date: "2024-06-22T20:15:00.000Z",
    venue: "The Forum",
    venueCapacity: 17500,
    item: "Tour Beanie",
    category: "Accessories",
    size: null,
    quantity: 3,
    revenue: 60.0,
    sellerId: "seller3",
    sellerName: "Alex Johnson",
    sellerRole: "SELLER",
  },
]

const mockInventoryItems = [
  {
    showId: "show1",
    showName: "Madison Square Garden",
    showDate: "2025-06-15T19:00:00.000Z",
    venue: "Madison Square Garden",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "S",
    currentStock: 5,
    initialStock: 50,
    soldCount: 45,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
  },
  {
    showId: "show1",
    showName: "Madison Square Garden",
    showDate: "2025-06-15T19:00:00.000Z",
    venue: "Madison Square Garden",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "M",
    currentStock: 25,
    initialStock: 50,
    soldCount: 25,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
  },
  {
    showId: "show1",
    showName: "Madison Square Garden",
    showDate: "2025-06-15T19:00:00.000Z",
    venue: "Madison Square Garden",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "L",
    currentStock: 15,
    initialStock: 50,
    soldCount: 35,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
  },
  {
    showId: "show1",
    showName: "Madison Square Garden",
    showDate: "2025-06-15T19:00:00.000Z",
    venue: "Madison Square Garden",
    item: "Tour Hoodie",
    category: "Hoodies",
    size: "M",
    currentStock: 10,
    initialStock: 30,
    soldCount: 20,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
  },
  {
    showId: "show1",
    showName: "Madison Square Garden",
    showDate: "2025-06-15T19:00:00.000Z",
    venue: "Madison Square Garden",
    item: "Tour Hoodie",
    category: "Hoodies",
    size: "L",
    currentStock: 0,
    initialStock: 30,
    soldCount: 30,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
  },
  {
    showId: "show1",
    showName: "Madison Square Garden",
    showDate: "2025-06-15T19:00:00.000Z",
    venue: "Madison Square Garden",
    item: "Tour Poster",
    category: "Posters",
    size: null,
    currentStock: 25,
    initialStock: 100,
    soldCount: 75,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
  },
  {
    showId: "show1",
    showName: "Madison Square Garden",
    showDate: "2025-06-15T19:00:00.000Z",
    venue: "Madison Square Garden",
    item: "Tour Beanie",
    category: "Accessories",
    size: null,
    currentStock: 20,
    initialStock: 50,
    soldCount: 30,
    damagedCount: 0,
    lostCount: 0,
    restockCount: 0,
  },
]

const mockInventoryAlerts = [
  {
    showId: "show1",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "S",
    currentStock: 5,
    initialStock: 50,
    alertType: "Low Stock",
    stockPercentage: 10,
  },
  {
    showId: "show1",
    item: "Tour Hoodie",
    category: "Hoodies",
    size: "L",
    currentStock: 0,
    initialStock: 30,
    alertType: "Out of Stock",
    stockPercentage: 0,
  },
  {
    showId: "show2",
    item: "Tour Logo Tee",
    category: "T-Shirts",
    size: "S",
    currentStock: 10,
    initialStock: 50,
    alertType: "Low Stock",
    stockPercentage: 20,
  },
]

const mockInventoryAggregates = [
  {
    category: "T-Shirts",
    totalItems: 3,
    totalCurrentStock: 45,
    totalInitialStock: 150,
    totalSold: 105,
    totalDamaged: 0,
    totalLost: 0,
    stockPercentage: 30,
  },
  {
    category: "Hoodies",
    totalItems: 2,
    totalCurrentStock: 10,
    totalInitialStock: 60,
    totalSold: 50,
    totalDamaged: 0,
    totalLost: 0,
    stockPercentage: 17,
  },
  {
    category: "Posters",
    totalItems: 1,
    totalCurrentStock: 25,
    totalInitialStock: 100,
    totalSold: 75,
    totalDamaged: 0,
    totalLost: 0,
    stockPercentage: 25,
  },
  {
    category: "Accessories",
    totalItems: 1,
    totalCurrentStock: 20,
    totalInitialStock: 50,
    totalSold: 30,
    totalDamaged: 0,
    totalLost: 0,
    stockPercentage: 40,
  },
]

const mockTourDemographics = {
  ageGroups: ["18-24", "25-34", "35-44", "45-54", "55+"],
  ageDistribution: {
    "18-24": 30,
    "25-34": 35,
    "35-44": 20,
    "45-54": 10,
    "55+": 5,
  },
  genderSplit: { male: "55%", female: "45%" },
  topSellingItems: [
    { item: "Tour Logo Tee (M)", quantity: 45, revenue: 1125.0 },
    { item: "Tour Hoodie (L)", quantity: 30, revenue: 1650.0 },
    { item: "Tour Poster", quantity: 75, revenue: 1500.0 },
  ],
  averageSpendPerAttendee: 15.75,
}
